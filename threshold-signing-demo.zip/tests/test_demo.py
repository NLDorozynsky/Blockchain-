from thsign import gen_keypair, schnorr_sign, schnorr_verify, mp_keygen, mp_sign, mp_verify, shamir_split, shamir_reconstruct
import itertools
def test_schnorr():
    x,P=gen_keypair(); m=b'test'; R,s=schnorr_sign(x,m); assert schnorr_verify(P,m,(R,s))
def test_shamir():
    x,P=gen_keypair(); shares=shamir_split(x,3,5)
    for subset in itertools.combinations(shares,3):
        assert shamir_reconstruct(list(subset))==x
def test_mp():
    xs,Xs,x,P=mp_keygen(3); m=b'multi'; R,s,Pagg=mp_sign(xs,m); assert mp_verify(Pagg,m,(R,s))
