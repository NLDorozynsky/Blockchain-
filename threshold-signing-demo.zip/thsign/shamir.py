from __future__ import annotations
from typing import List, Tuple
from .ecc import n
import secrets
def _eval(coeffs:List[int], x:int, mod:int)->int:
    r=0
    for c in reversed(coeffs): r=(r*x+c)%mod
    return r
def split(secret:int,t:int,nparts:int,mod:int=n)->List[Tuple[int,int]]:
    assert 2<=t<=nparts
    coeffs=[secret]+[secrets.randbelow(mod-1)+1 for _ in range(t-1)]
    return [(i,_eval(coeffs,i,mod)) for i in range(1,nparts+1)]
def reconstruct(subset:List[Tuple[int,int]],mod:int=n)->int:
    s=0
    for j,(xj,yj) in enumerate(subset):
        num,den=1,1
        for m,(xm,_) in enumerate(subset):
            if m==j: continue
            num=(num*(-xm))%mod; den=(den*(xj-xm))%mod
        lj=(num*pow(den,-1,mod))%mod; s=(s+yj*lj)%mod
    return s
