from __future__ import annotations
from typing import List, Tuple
from .ecc import G,n,mul,H,gen,Point,add
import secrets
def sign(x:int,m:bytes)->Tuple[Point,int]:
    k=secrets.randbelow(n-1)+1; R=mul(k,G); e=H(R.x.to_bytes(32,'big'),m); s=(k+e*x)%n; return R,s
def verify(P:Point,m:bytes,sig:Tuple[Point,int])->bool:
    R,s=sig; e=H(R.x.to_bytes(32,'big'),m); return mul(s,G)==add(R,mul(e,P))
def mp_keygen(nparties:int)->Tuple[List[int],List[Point],int,Point]:
    xs=[]; Xs=[]; 
    for _ in range(nparties): xi, Xi = gen(); xs.append(xi); Xs.append(Xi)
    x=sum(xs)%n; P=mul(x,G); return xs,Xs,x,P
def mp_sign(xs:List[int],m:bytes)->Tuple[Point,int,Point]:
    kis=[secrets.randbelow(n-1)+1 for _ in xs]; Ris=[mul(k,G) for k in kis]
    R=Ris[0]
    for Ri in Ris[1:]: R=add(R,Ri)
    P=mul(sum(xs)%n,G); e=H(R.x.to_bytes(32,'big'),m)
    s=sum((kis[i]+e*xs[i])%n for i in range(len(xs)))%n
    return R,s,P
def mp_verify(P:Point,m:bytes,sig:Tuple[Point,int])->bool:
    R,s=sig; e=H(R.x.to_bytes(32,'big'),m); return mul(s,G)==add(R,mul(e,P))
