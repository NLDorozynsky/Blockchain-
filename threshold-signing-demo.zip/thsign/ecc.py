from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple
import hashlib, secrets
p=0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F
Gx=55066263022277343669578718895168534326250603453777594175500187360389116729240
Gy=32670510020758816978083085130507043184471273380659243275938904335757337482424
n=0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
def inv(x:int,m:int=p)->int: return pow(x,m-2,m)
@dataclass(frozen=True) class Point: x:Optional[int]; y:Optional[int]
INF=Point(None,None); G=Point(Gx,Gy)
def add(P:Point,Q:Point)->Point:
    if P.x is None: return Q
    if Q.x is None: return P
    if P.x==Q.x and (P.y!=Q.y or P.y==0): return INF
    if P.x==Q.x and P.y==Q.y: lam=(3*P.x*P.x)*inv((2*P.y)%p,p)%p
    else: lam=((Q.y-P.y)%p)*inv((Q.x-P.x)%p,p)%p
    rx=(lam*lam-P.x-Q.x)%p; ry=(lam*(P.x-rx)-P.y)%p; return Point(rx,ry)
def mul(k:int,P:Point=G)->Point:
    k%=n
    if k==0 or P.x is None: return INF
    R=INF; Q=P
    while k>0:
        if k&1: R=add(R,Q)
        Q=add(Q,Q); k>>=1
    return R
def H(*msgs:bytes)->int:
    h=hashlib.sha256(); [h.update(m) for m in msgs]; return int.from_bytes(h.digest(),'big')%n
def gen()->Tuple[int,Point]:
    x=secrets.randbelow(n-1)+1; return x, mul(x,G)
