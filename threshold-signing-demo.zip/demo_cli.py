#!/usr/bin/env python3
import argparse, random
from thsign import gen_keypair, schnorr_sign, schnorr_verify, mp_keygen, mp_sign, mp_verify, shamir_split, shamir_reconstruct
def main():
    ap=argparse.ArgumentParser(description='Threshold Signing Demo (toy)')
    sub=ap.add_subparsers(dest='cmd')
    p1=sub.add_parser('shamir-sign'); p1.add_argument('--n',type=int,default=5); p1.add_argument('--t',type=int,default=3); p1.add_argument('--msg',type=str,default='hello threshold')
    p2=sub.add_parser('mp-schnorr'); p2.add_argument('--n',type=int,default=3); p2.add_argument('--msg',type=str,default='hello multisig')
    args=ap.parse_args()
    if args.cmd=='shamir-sign':
        x,P=gen_keypair(); shares=shamir_split(x,args.t,args.n); subset=random.sample(shares,args.t); xr=shamir_reconstruct(subset); R,s=schnorr_sign(xr,args.msg.encode()); print('ok?',schnorr_verify(P,args.msg.encode(),(R,s)))
    elif args.cmd=='mp-schnorr':
        xs,Xs,x,P=mp_keygen(args.n); R,s,Pagg=mp_sign(xs,args.msg.encode()); print('ok?', mp_verify(Pagg,args.msg.encode(),(R,s)))
    else:
        ap.print_help()
if __name__=='__main__': main()
