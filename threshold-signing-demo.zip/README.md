# Threshold Signing Demo (toy) — Python

Demos:
- Shamir t-of-n Secret Sharing + Schnorr (reconstruct then sign)
- n-of-n Multi‑party Schnorr (MuSig-like), no key reconstruction

Usage:
```bash
python demo_cli.py shamir-sign --n 5 --t 3 --msg "hello"
python demo_cli.py mp-schnorr --n 3 --msg "hi"
python -m pytest -q
```

Educational only.
