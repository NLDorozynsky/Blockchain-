# The Graph Subgraph Template — Graph Protocol

A minimal **subgraph template** for indexing **ERC‑20 `Transfer` events**, with configurable networks,
basic **Token / Account / Transfer / TokenBalance** entities, and mappings written in AssemblyScript.

> Educational scaffold — adjust to your protocol. Tested with `@graphprotocol/graph-cli` v0.58+.

## What this includes
- `schema.graphql` — entities for tokens, accounts, balances, and transfers
- `src/mapping.ts` — handles `Transfer` events, updates balances, stores transfers
- `abis/erc20.json` — minimal ERC‑20 ABI (Transfer)
- `subgraph.yaml` — manifest with placeholders (uses `./networks.json`)
- `networks.json` — per-network contract address + startBlock
- `package.json` — scripts: `graph codegen`, `graph build`, `graph deploy`
- CI: `.github/workflows/graph.yml` (codegen + build)

## Quick start
```bash
# 1) Install
npm i

# 2) Configure addresses
#   edit networks.json with your contract address & startBlock

# 3) Codegen & build
npm run codegen
npm run build

# 4) Deploy
#   For Subgraph Studio:
#   export GRAPH_ACCESS_TOKEN=...
#   npm run deploy -- --studio <subgraph-name>
#
#   For Hosted Service (legacy, if enabled for your chain):
#   npm run deploy -- --product hosted-service <GITHUB_USER>/<SUBGRAPH_NAME>
```

### Files
- **subgraph.yaml** — uses the address for `{{network}}` from `networks.json`; edit to match your target chain
- **src/mapping.ts** — example handler for `Transfer`
- **schema.graphql** — entities with **derived fields** for convenience
