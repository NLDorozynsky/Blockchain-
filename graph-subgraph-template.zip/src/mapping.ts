import { Address, BigInt, Bytes, ethereum } from '@graphprotocol/graph-ts'
import { Transfer as TransferEvent } from '../generated/ERC20/ERC20'
import { Token, Account, TokenBalance, Transfer } from '../generated/schema'

function tokenId(addr: Address): string { return addr.toHexString() }
function accountId(addr: Address): string { return addr.toHexString() }
function balanceId(token: Address, acct: Address): string { return token.toHexString() + '-' + acct.toHexString() }

function getOrCreateToken(addr: Address): Token {
  let id = tokenId(addr)
  let t = Token.load(id)
  if (t == null) {
    t = new Token(id)
    t.totalTransfers = BigInt.zero()
    t.save()
  }
  return t as Token
}

function getOrCreateAccount(addr: Address): Account {
  let id = accountId(addr)
  let a = Account.load(id)
  if (a == null) {
    a = new Account(id)
    a.save()
  }
  return a as Account
}

function getOrCreateBalance(token: Address, acct: Address): TokenBalance {
  let id = balanceId(token, acct)
  let b = TokenBalance.load(id)
  if (b == null) {
    b = new TokenBalance(id)
    b.token = tokenId(token)
    b.account = accountId(acct)
    b.balance = BigInt.zero()
    b.save()
  }
  return b as TokenBalance
}

export function handleTransfer(event: TransferEvent): void {
  let token = getOrCreateToken(event.address)
  token.totalTransfers = token.totalTransfers.plus(BigInt.fromI32(1))
  token.save()

  let from = getOrCreateAccount(event.params.from)
  let to = getOrCreateAccount(event.params.to)

  // Update balances (best-effort; relies on transfer events)
  let fromBal = getOrCreateBalance(event.address, event.params.from)
  if (fromBal.balance >= event.params.value) {
    fromBal.balance = fromBal.balance.minus(event.params.value)
  } else {
    fromBal.balance = BigInt.zero() // avoid negative underflows
  }
  fromBal.save()

  let toBal = getOrCreateBalance(event.address, event.params.to)
  toBal.balance = toBal.balance.plus(event.params.value)
  toBal.save()

  let tr = new Transfer(event.transaction.hash.toHexString() + '-' + event.logIndex.toString())
  tr.token = token.id
  tr.from = from.id
  tr.to = to.id
  tr.value = event.params.value
  tr.txHash = event.transaction.hash
  tr.blockNumber = event.block.number
  tr.timestamp = event.block.timestamp
  tr.save()
}
