import { generateMnemonic, mnemonicToSeed, HDNode, networks, bip44Path, CoinTypes, ethAddress, btcP2pkhAddress } from '../src/index.js';

async function main() {
  const mnemonic = generateMnemonic(128);
  console.log('Mnemonic:', mnemonic);

  const seed = await mnemonicToSeed(mnemonic);
  const root = await HDNode.fromSeed(seed, networks.mainnet);

  // ETH m/44'/60'/0'/0/0
  const ethNode = await root.derivePath(bip44Path(CoinTypes.ETH, 0, 0, 0));
  console.log('ETH xpub:', ethNode.neuter().toXPub());
  console.log('ETH address:', ethAddress(ethNode.publicKey));

  // BTC m/44'/0'/0'/0/0
  const btcNode = await root.derivePath(bip44Path(CoinTypes.BTC, 0, 0, 0));
  console.log('BTC xpub:', btcNode.neuter().toXPub());
  console.log('BTC P2PKH:', btcP2pkhAddress(btcNode.publicKey));

  // Show xprv (do not print xprv in real apps)
  console.log('Master xprv:', root.toXPrv());
}

main().catch(console.error);
