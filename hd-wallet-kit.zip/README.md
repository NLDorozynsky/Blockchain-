# HD Wallet Kit (BIP32/39/44) — TypeScript

A compact, educational HD wallet toolkit that supports:

- **BIP39** mnemonics (generate/validate → seed)
- **BIP32** hierarchical deterministic keys (CKDpriv, xprv/xpub serialization)
- **BIP44** path helpers (e.g., `m/44'/60'/0'/0/0`)
- **Addresses**: Ethereum (EIP-55 checksum), Bitcoin P2PKH (Base58Check)

> ⚠️ Educational only — not audited. Do not use with real funds.

## Quick start
```bash
npm i
npm run build

# Demo (generates a mnemonic and derives ETH & BTC addresses)
npm run dev
```

## API (high-level)
```ts
import { generateMnemonic, mnemonicToSeed } from 'hd-wallet-kit';
import { HDNode, parsePath, bip44Account, networks, ethAddress, btcP2pkhAddress } from 'hd-wallet-kit';

const mnemonic = generateMnemonic(128);
const seed = await mnemonicToSeed(mnemonic);

// Root node (mainnet)
const root = HDNode.fromSeed(seed, networks.mainnet);

// Derive by path
const node = root.derivePath("m/44'/60'/0'/0/0");
const ethAddr = ethAddress(node.publicKey);

// Bitcoin P2PKH
const btcNode = root.derivePath("m/44'/0'/0'/0/0");
const btcAddr = btcP2pkhAddress(btcNode.publicKey, networks.mainnet);
```

See `examples/demo.ts` for a full example.
