// BIP32 minimal implementation for secp256k1
import * as secp from '@noble/secp256k1';
import { hmacSHA512, sha256Hex, hash160, compressPublicKey, base58checkEncode } from './utils.js';

const MASTER_SECRET = new TextEncoder().encode('Bitcoin seed');
const HARDENED_OFFSET = 0x80000000;

export type Network = {
  xprv: number;
  xpub: number;
  bip32Public: number; // alias of xpub
  bip32Private: number; // alias of xprv
  p2pkh: number; // version byte for P2PKH addresses
};

export const networks = {
  mainnet: { xprv: 0x0488ade4, xpub: 0x0488b21e, bip32Public: 0x0488b21e, bip32Private: 0x0488ade4, p2pkh: 0x00 } as Network,
  testnet: { xprv: 0x04358394, xpub: 0x043587cf, bip32Public: 0x043587cf, bip32Private: 0x04358394, p2pkh: 0x6f } as Network,
};

function ser32(i: number): Uint8Array {
  const b = new Uint8Array(4);
  b[0] = (i >>> 24) & 0xff; b[1] = (i >>> 16) & 0xff; b[2] = (i >>> 8) & 0xff; b[3] = i & 0xff;
  return b;
}

function ser256(p: Uint8Array): Uint8Array {
  if (p.length !== 32) throw new Error('ser256 expects 32 bytes');
  return p;
}

function parse256(p: Uint8Array): bigint {
  if (p.length !== 32) throw new Error('parse256 expects 32 bytes');
  return BigInt('0x' + Buffer.from(p).toString('hex'));
}

function i2hex(i: number): Uint8Array {
  return ser32(i);
}

function numberToBytesBE(num: number, len: number): Uint8Array {
  const out = new Uint8Array(len);
  for (let i = len - 1; i >= 0; i--) {
    out[i] = num & 0xff; num >>>= 8;
  }
  return out;
}

export class HDNode {
  readonly privateKey?: Uint8Array;
  readonly publicKey: Uint8Array; // compressed
  readonly chainCode: Uint8Array;
  readonly depth: number;
  readonly index: number;
  readonly parentFingerprint: number;
  readonly network: Network;

  private constructor(opts: { privateKey?: Uint8Array; publicKey: Uint8Array; chainCode: Uint8Array; depth: number; index: number; parentFingerprint: number; network: Network }) {
    this.privateKey = opts.privateKey;
    this.publicKey = opts.publicKey;
    this.chainCode = opts.chainCode;
    this.depth = opts.depth;
    this.index = opts.index;
    this.parentFingerprint = opts.parentFingerprint;
    this.network = opts.network;
  }

  static async fromSeed(seed: Uint8Array, network: Network = networks.mainnet): Promise<HDNode> {
    const I = await hmacSHA512(MASTER_SECRET, seed);
    const IL = I.slice(0, 32);
    const IR = I.slice(32);
    const priv = IL;
    if (!secp.utils.isValidPrivateKey(priv)) throw new Error('Invalid master key');
    const pub = compressPublicKey(secp.getPublicKey(priv, true));
    return new HDNode({ privateKey: priv, publicKey: pub, chainCode: IR, depth: 0, index: 0, parentFingerprint: 0, network });
  }

  fingerprint(): number {
    const h160 = hash160(this.publicKey);
    return ((h160[0] << 24) | (h160[1] << 16) | (h160[2] << 8) | h160[3]) >>> 0;
  }

  neuter(): HDNode {
    return new HDNode({ publicKey: this.publicKey, chainCode: this.chainCode, depth: this.depth, index: this.index, parentFingerprint: this.parentFingerprint, network: this.network });
  }

  async derive(index: number): Promise<HDNode> {
    if (this.privateKey) {
      const isHardened = index >= HARDENED_OFFSET;
      let data: Uint8Array;
      if (isHardened) {
        const pk = this.privateKey;
        data = new Uint8Array(1 + pk.length + 4);
        data.set([0x00], 0);
        data.set(pk, 1);
        data.set(ser32(index), 33);
      } else {
        const pub = this.publicKey;
        data = new Uint8Array(pub.length + 4);
        data.set(pub, 0);
        data.set(ser32(index), pub.length);
      }
      const I = await hmacSHA512(this.chainCode, data);
      const IL = I.slice(0, 32);
      const IR = I.slice(32);
      if (!secp.utils.isValidPrivateKey(IL)) throw new Error('Invalid child key (IL)');
      const ki = secp.utils.mod(BigInt('0x' + Buffer.from(IL).toString('hex')) + BigInt('0x' + Buffer.from(this.privateKey).toString('hex')), secp.CURVE.n);
      if (ki === 0n) throw new Error('Zero child key');
      const priv = numberToBytesBE(Number(ki % (1n << 256n)), 32); // convert bigint to 32 bytes
      const pub = compressPublicKey(secp.getPublicKey(priv, true));
      return new HDNode({ privateKey: priv, publicKey: pub, chainCode: IR, depth: this.depth + 1, index, parentFingerprint: this.fingerprint(), network: this.network });
    } else {
      // Public derivation (non-hardened only)
      if (index >= HARDENED_OFFSET) throw new Error('Cannot derive hardened from public node');
      const data = new Uint8Array(this.publicKey.length + 4);
      data.set(this.publicKey, 0);
      data.set(ser32(index), this.publicKey.length);
      const I = await hmacSHA512(this.chainCode, data);
      const IL = I.slice(0, 32);
      const IR = I.slice(32);
      const Ki = secp.Point.fromHex(this.publicKey).add(secp.Point.fromPrivateKey(IL));
      const pub = Ki.toRawBytes(true);
      return new HDNode({ publicKey: pub, chainCode: IR, depth: this.depth + 1, index, parentFingerprint: this.fingerprint(), network: this.network });
    }
  }

  async derivePath(path: string): Promise<HDNode> {
    const parts = parsePath(path);
    let node: HDNode = this;
    for (const p of parts) {
      node = await node.derive(p);
    }
    return node;
  }

  // Serialization (xpub/xprv)
  toXPrv(): string {
    if (!this.privateKey) throw new Error('No private key');
    const version = this.network.xprv;
    const payload = new Uint8Array(78);
    payload.set(new Uint8Array([(version >>> 24) & 0xff, (version >>> 16) & 0xff, (version >>> 8) & 0xff, version & 0xff]), 0);
    payload[4] = this.depth & 0xff;
    payload.set(new Uint8Array([(this.parentFingerprint >>> 24) & 0xff, (this.parentFingerprint >>> 16) & 0xff, (this.parentFingerprint >>> 8) & 0xff, this.parentFingerprint & 0xff]), 5);
    payload.set(ser32(this.index), 9);
    payload.set(this.chainCode, 13);
    const keyData = new Uint8Array(33); keyData[0] = 0x00; keyData.set(this.privateKey, 1);
    payload.set(keyData, 45);
    return base58checkEncode(payload);
  }

  toXPub(): string {
    const version = this.network.xpub;
    const payload = new Uint8Array(78);
    payload.set(new Uint8Array([(version >>> 24) & 0xff, (version >>> 16) & 0xff, (version >>> 8) & 0xff, version & 0xff]), 0);
    payload[4] = this.depth & 0xff;
    payload.set(new Uint8Array([(this.parentFingerprint >>> 24) & 0xff, (this.parentFingerprint >>> 16) & 0xff, (this.parentFingerprint >>> 8) & 0xff, this.parentFingerprint & 0xff]), 5);
    payload.set(ser32(this.index), 9);
    payload.set(this.chainCode, 13);
    payload.set(this.publicKey, 45);
    return base58checkEncode(payload);
  }
}

// Path helpers
export function parsePath(path: string): number[] {
  if (!path || path === 'm') return [];
  if (!path.startsWith('m/')) throw new Error('Path must start with m/');
  return path.slice(2).split('/').map((p) => {
    const hard = p.endsWith("'");
    const n = parseInt(hard ? p.slice(0, -1) : p, 10);
    if (Number.isNaN(n)) throw new Error(`Invalid path segment: ${p}`);
    return hard ? (n + 0x80000000) >>> 0 : n >>> 0;
  });
}

export const HARDENED_OFFSET = 0x80000000;
