import * as bip39 from 'bip39';

export function generateMnemonic(strength: 128|160|192|224|256 = 128): string {
  return bip39.generateMnemonic(strength);
}

export function validateMnemonic(mnemonic: string): boolean {
  return bip39.validateMnemonic(mnemonic);
}

export async function mnemonicToSeed(mnemonic: string, passphrase = ''): Promise<Uint8Array> {
  const seed = await bip39.mnemonicToSeed(mnemonic, passphrase);
  return new Uint8Array(seed);
}
