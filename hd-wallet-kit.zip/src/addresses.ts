import * as secp from '@noble/secp256k1';
import { keccak_256 } from '@noble/hashes/sha3';
import { hash160 } from './utils.js';
import { networks, Network } from './bip32.js';
import { base58checkEncode } from './utils.js';

export function ethAddress(pubkeyCompressed: Uint8Array): string {
  const uncompressed = secp.Point.fromHex(pubkeyCompressed).toRawBytes(false); // 65 bytes
  const addrBytes = keccak_256(uncompressed.slice(1)).slice(-20);
  const lower = Buffer.from(addrBytes).toString('hex');
  // EIP-55 checksum
  const hash = Buffer.from(keccak_256(Buffer.from(lower, 'utf8'))).toString('hex');
  let out = '0x';
  for (let i = 0; i < lower.length; i++) {
    out += parseInt(hash[i], 16) >= 8 ? lower[i].toUpperCase() : lower[i];
  }
  return out;
}

export function btcP2pkhAddress(pubkeyCompressed: Uint8Array, network: Network = networks.mainnet): string {
  const h160 = hash160(pubkeyCompressed);
  const payload = new Uint8Array(1 + h160.length);
  payload[0] = network.p2pkh;
  payload.set(h160, 1);
  return base58checkEncode(payload);
}
