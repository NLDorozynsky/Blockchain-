import { sha256 } from '@noble/hashes/sha256';
import { ripemd160 } from '@noble/hashes/ripemd160';
import { keccak_256 } from '@noble/hashes/sha3';
import * as secp from '@noble/secp256k1';
import bs58check from 'bs58check';

export function hmacSHA512(key: Uint8Array, data: Uint8Array): Uint8Array {
  // Noble exposes utils.hmacSha256/sha256, not sha512; implement local HMAC-SHA512 using Web Crypto if present,
  // but to keep it cross-env we implement minimal HMAC-SHA512 via SubtleCrypto if available.
  // For simplicity and portability, we use Node's crypto if available; otherwise throw instructive error.
  try {
    // @ts-ignore
    const cr = await import('node:crypto');
    const h = cr.createHmac('sha512', Buffer.from(key));
    h.update(Buffer.from(data));
    return new Uint8Array(h.digest());
  } catch {
    throw new Error('HMAC-SHA512 is required; run in Node.js environment.');
  }
}

export function toHex(bytes: Uint8Array): string {
  return '0x' + Buffer.from(bytes).toString('hex');
}

export function fromHex(hex: string): Uint8Array {
  const h = hex.startsWith('0x') ? hex.slice(2) : hex;
  return new Uint8Array(Buffer.from(h, 'hex'));
}

export function sha256Hex(data: Uint8Array): Uint8Array {
  return sha256(data);
}

export function hash160(data: Uint8Array): Uint8Array {
  return ripemd160(sha256(data));
}

export function toChecksumAddress(addressLowerNo0x: string): string {
  const hash = Buffer.from(keccak_256(Buffer.from(addressLowerNo0x, 'utf8'))).toString('hex');
  let ret = '0x';
  for (let i = 0; i < addressLowerNo0x.length; i++) {
    ret += parseInt(hash[i], 16) >= 8 ? addressLowerNo0x[i].toUpperCase() : addressLowerNo0x[i];
  }
  return ret;
}

export function compressPublicKey(pubkey: Uint8Array): Uint8Array {
  // pubkey from noble can be uncompressed if length 65; we return compressed 33 bytes
  return secp.Point.fromHex(pubkey).toRawBytes(true);
}

export function uncompressedPublicKey(pubkey: Uint8Array): Uint8Array {
  return secp.Point.fromHex(pubkey).toRawBytes(false);
}

export function base58checkEncode(payload: Uint8Array): string {
  return bs58check.encode(Buffer.from(payload));
}
