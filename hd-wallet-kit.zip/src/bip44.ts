// BIP44 helpers
import { parsePath, HARDENED_OFFSET } from './bip32.js';

export function bip44Path(coinType: number, account = 0, change = 0, index = 0): string {
  return `m/44'/${coinType}'/${account}'/${change}/${index}`;
}

export const CoinTypes = {
  BTC: 0,
  TESTNET: 1,
  ETH: 60,
  SOL: 501,
  MATIC: 137,
  BNB: 714,
};
