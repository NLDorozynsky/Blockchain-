import { describe, it, expect } from 'vitest';
import { generateMnemonic, mnemonicToSeed, HDNode, networks, bip44Path, CoinTypes } from '../src/index.js';

describe('HD Wallet Kit', () => {
  it('generates mnemonic and derives path', async () => {
    const m = generateMnemonic(128);
    expect(m.split(' ').length).toBe(12);
    const seed = await mnemonicToSeed(m);
    const root = await HDNode.fromSeed(seed, networks.mainnet);
    const node = await root.derivePath(bip44Path(CoinTypes.ETH, 0, 0, 0));
    expect(node.publicKey.length).toBe(33);
  });
});
