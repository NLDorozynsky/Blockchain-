
use anyhow::Result;
use clap::Parser;
use serde::Deserialize;
use std::collections::BTreeMap;
use ordered_float::OrderedFloat;

#[derive(Debug, Deserialize)]
struct Scenario {
    matching_pool: f64,
    // contributions[project][contributor] = amount
    contributions: BTreeMap<String, BTreeMap<String, f64>>,
}

#[derive(Parser, Debug)]
struct Args {
    /// Input JSON scenario (see examples/)
    #[arg(short, long)]
    input: String,
}

fn sqrt(x: f64) -> f64 { x.sqrt() }

fn main() -> Result<()> {
    let args = Args::parse();
    let data = std::fs::read_to_string(&args.input)?;
    let sc: Scenario = serde_json::from_str(&data)?;

    // Compute direct totals and QF need per project
    // qf_need = (sum sqrt(contribs))^2 - sum(contribs)
    let mut direct: BTreeMap<String, f64> = BTreeMap::new();
    let mut need: BTreeMap<String, f64> = BTreeMap::new();
    for (project, contribs) in &sc.contributions {
        let sum_direct: f64 = contribs.values().copied().sum();
        let sum_sqrt: f64 = contribs.values().map(|a| sqrt(*a)).sum();
        let s_sq = sum_sqrt * sum_sqrt;
        let qf_need = (s_sq - sum_direct).max(0.0);
        direct.insert(project.clone(), sum_direct);
        need.insert(project.clone(), qf_need);
    }
    let total_need: f64 = need.values().copied().sum();

    // Allocations
    let mut matching: BTreeMap<String, f64> = BTreeMap::new();
    if total_need > 0.0 && sc.matching_pool > 0.0 {
        for (project, n) in &need {
            matching.insert(project.clone(), sc.matching_pool * (n / total_need));
        }
    } else {
        for p in need.keys() { matching.insert(p.clone(), 0.0); }
    }

    // Print report
    println!("Quadratic Funding Allocation");
    println!("Matching pool: {:.2}", sc.matching_pool);
    println!();
    let mut rows: Vec<_> = direct.keys().cloned().collect();
    rows.sort();
    println!("{:<20} {:>12} {:>12} {:>12}", "Project", "Direct", "Match", "Total");
    for p in rows {
        let d = direct.get(&p).cloned().unwrap_or(0.0);
        let m = matching.get(&p).cloned().unwrap_or(0.0);
        println!("{:<20} {:>12.2} {:>12.2} {:>12.2}", p, d, m, d + m);
    }

    // Most benefited project (for fun)
    if let Some((proj, amt)) = matching.iter().max_by_key(|(_, v)| OrderedFloat(**v)) {
        println!("
Top match: {} (+{:.2})", proj, amt);
    }
    Ok(())
}
