
#![cfg_attr(not(feature = "std"), no_std)]

//! Quadratic Funding pallet (educational scaffold)
//!
//! ## Model (simplified)
//! - A **campaign** has an `organizer`, a **matching_pool** reserved from the organizer's funds,
//!   and receives **donations** to **projects** (here, `ProjectId = T::AccountId` for simplicity).
//! - `donate` transfers (escrows) funds to the pallet account.
//! - `finalize` computes QF matching for each project and disburses:
//!     * donated funds + a share of the matching pool, then marks campaign finalized.
//!     * matching funds are moved from organizer's **reserved** to recipient **free** balance.
//!
//! This pallet focuses on the accounting and QF math; integrate into a real runtime to wire
//! origins, weights, and benchmarking per your chain's standards.

use frame_support::{
    pallet_prelude::*,
    traits::{Currency, ExistenceRequirement, ReservableCurrency, Get, tokens::BalanceStatus, WithdrawReasons},
};
use frame_system::pallet_prelude::*;
use sp_runtime::traits::{AccountIdConversion, Zero};
use sp_std::{vec::Vec, collections::btree_map::BTreeMap};

#[frame_support::pallet]
pub mod pallet {
    use super::*;

    pub type BalanceOf<T> =
        <<T as Config>::Currency as Currency<<T as frame_system::Config>::AccountId>>::Balance;

    /// A campaign identifier
    pub type CampaignId = u32;

    #[pallet::config]
    pub trait Config: frame_system::Config {
        type RuntimeEvent: From<Event<Self>> + IsType<<Self as frame_system::Config>::RuntimeEvent>;

        /// Currency used for contributions and payouts.
        type Currency: ReservableCurrency<Self::AccountId>;

        /// Pallet identifier to derive the escrow account.
        #[pallet::constant]
        type PalletId: Get<frame_support::PalletId>;
    }

    #[pallet::pallet]
    pub struct Pallet<T>(_);

    #[pallet::storage]
    #[pallet::getter(fn next_campaign_id)]
    pub type NextCampaignId<T> = StorageValue<_, CampaignId, ValueQuery>;

    #[derive(Clone, Encode, Decode, TypeInfo, MaxEncodedLen, RuntimeDebug, PartialEq, Eq)]
    pub struct Campaign<T: Config> {
        pub organizer: T::AccountId,
        pub matching_pool: BalanceOf<T>,
        pub finalized: bool,
    }

    #[pallet::storage]
    #[pallet::getter(fn campaigns)]
    pub type Campaigns<T: Config> = StorageMap<_, Blake2_128Concat, CampaignId, Campaign<T>>;

    /// Contributions keyed by (campaign, project, contributor) -> amount
    #[pallet::storage]
    pub type Contributions<T: Config> = StorageDoubleMap<
        _,
        Blake2_128Concat, CampaignId,
        Blake2_128Concat, (T::AccountId, T::AccountId), // (project, contributor)
        BalanceOf<T>,
        ValueQuery
    >;

    /// Sum of contributions per project (campaign, project) -> total
    #[pallet::storage]
    pub type ProjectTotals<T: Config> = StorageDoubleMap<
        _,
        Blake2_128Concat, CampaignId,
        Blake2_128Concat, T::AccountId, // project
        BalanceOf<T>,
        ValueQuery
    >;

    #[pallet::event]
    #[pallet::generate_deposit(pub(super) fn deposit_event)]
    pub enum Event<T: Config> {
        CampaignCreated { id: CampaignId, organizer: T::AccountId, matching_pool: BalanceOf<T> },
        Donated { id: CampaignId, project: T::AccountId, from: T::AccountId, amount: BalanceOf<T> },
        Finalized { id: CampaignId },
    }

    #[pallet::error]
    pub enum Error<T> {
        CampaignNotFound,
        AlreadyFinalized,
        NotOrganizer,
        ZeroAmount,
        Overflow,
        InsufficientReserved,
    }

    #[pallet::call]
    impl<T: Config> Pallet<T> {

        /// Create a campaign reserving `matching_pool` from origin (organizer).
        #[pallet::weight(10_000)]
        pub fn create_campaign(origin: OriginFor<T>, matching_pool: BalanceOf<T>) -> DispatchResult {
            let who = ensure_signed(origin)?;
            ensure!(!matching_pool.is_zero(), Error::<T>::ZeroAmount);

            T::Currency::reserve(&who, matching_pool).map_err(|_| Error::<T>::InsufficientReserved)?;

            let id = NextCampaignId::<T>::get();
            NextCampaignId::<T>::put(id.saturating_add(1));

            Campaigns::<T>::insert(id, Campaign::<T> {
                organizer: who.clone(),
                matching_pool,
                finalized: false,
            });

            Self::deposit_event(Event::CampaignCreated { id, organizer: who, matching_pool });
            Ok(())
        }

        /// Donate `amount` to a `project` (project is represented by an AccountId).
        /// Funds are transferred to the pallet's escrow account.
        #[pallet::weight(10_000)]
        pub fn donate(origin: OriginFor<T>, id: CampaignId, project: T::AccountId, amount: BalanceOf<T>) -> DispatchResult {
            let who = ensure_signed(origin)?;
            ensure!(!amount.is_zero(), Error::<T>::ZeroAmount);

            let camp = Campaigns::<T>::get(id).ok_or(Error::<T>::CampaignNotFound)?;
            ensure!(!camp.finalized, Error::<T>::AlreadyFinalized);

            // escrow to pallet account
            T::Currency::transfer(
                &who,
                &Self::escrow_account_id(),
                amount,
                ExistenceRequirement::AllowDeath
            )?;

            // accumulate contribution and totals
            let key = (project.clone(), who.clone());
            let prev = Contributions::<T>::get(id, key.clone());
            let new = prev.saturating_add(amount);
            Contributions::<T>::insert(id, key, new);

            let sum_prev = ProjectTotals::<T>::get(id, &project);
            let sum_new = sum_prev.saturating_add(amount);
            ProjectTotals::<T>::insert(id, &project, sum_new);

            Self::deposit_event(Event::Donated { id, project, from: who, amount });
            Ok(())
        }

        /// Finalize a campaign: compute quadratic funding allocation and disburse funds.
        /// Projects receive: (sum of direct donations held in escrow) + (their share of matching_pool).
        /// Matching pool is repatriated from organizer's reserved balance to project free balance.
        #[pallet::weight(50_000)]
        pub fn finalize(origin: OriginFor<T>, id: CampaignId) -> DispatchResult {
            let who = ensure_signed(origin)?;
            let mut camp = Campaigns::<T>::get(id).ok_or(Error::<T>::CampaignNotFound)?;
            ensure!(who == camp.organizer, Error::<T>::NotOrganizer);
            ensure!(!camp.finalized, Error::<T>::AlreadyFinalized);

            // Compute per-project QF scores and totals.
            // qf_score = (sum over contributors sqrt(amount_i))^2 - sum(amount_i)
            let mut per_project_s = BTreeMap::<T::AccountId, (BalanceOf<T>, BalanceOf<T>)>::new();
            let mut projects: Vec<T::AccountId> = Vec::new();

            // Collect project totals
            for (proj, total) in ProjectTotals::<T>::iter_key_prefix(id).map(|p| {
                let tot = ProjectTotals::<T>::get(id, &p);
                (p, tot)
            }) {
                projects.push(proj.clone());
                per_project_s.insert(proj.clone(), (Zero::zero(), total));
            }

            // Helper: fixed-point sqrt for Balance using u128 as backing (for demo)
            fn sqrt_u128(x: u128) -> u128 {
                // integer sqrt
                (x as f64).sqrt() as u128
            }

            // sum sqrt per project
            for proj in &projects {
                let mut sum_sqrt: u128 = 0;
                for (key, amount) in super::Contributions::<T>::iter_key_prefix(id)
                    .filter(|(p, _c)| p == proj)
                    .map(|k| {
                        let a = super::Contributions::<T>::get(id, k.clone());
                        (k, a)
                    })
                {
                    let a: u128 = amount.saturated_into::<u128>();
                    sum_sqrt = sum_sqrt.saturating_add(sqrt_u128(a));
                }
                // S = (sum sqrt)^2
                let s_sq = sum_sqrt.saturating_mul(sum_sqrt);
                let (_, direct_total) = per_project_s.get_mut(proj).expect("exists; qed");
                let direct_u: u128 = (*direct_total).saturated_into::<u128>();
                let matching_need_u = s_sq.saturating_sub(direct_u);
                // store matching_need (as Balance) alongside direct_total
                let matching_need: BalanceOf<T> = matching_need_u.saturated_into();
                per_project_s.insert(proj.clone(), (matching_need, *direct_total));
            }

            // Sum matching needs
            let mut total_need_u: u128 = 0;
            for (need, _dir) in per_project_s.values() {
                total_need_u = total_need_u.saturating_add((*need).saturated_into::<u128>());
            }
            let pool_u: u128 = camp.matching_pool.saturated_into::<u128>();

            // Disburse: transfer escrowed direct totals + proportional share of matching.
            for proj in projects {
                let (need, direct) = per_project_s.get(&proj).cloned().unwrap_or_default();
                // Transfer direct donations from escrow to project
                if !direct.is_zero() {
                    // move from escrow account
                    T::Currency::transfer(&Self::escrow_account_id(), &proj, direct, ExistenceRequirement::AllowDeath)?;
                }
                // matching
                if total_need_u > 0 && pool_u > 0 {
                    let need_u: u128 = need.saturated_into::<u128>();
                    let share_u = (need_u.saturating_mul(pool_u)) / total_need_u;
                    let share: BalanceOf<T> = share_u.saturated_into();
                    if !share.is_zero() {
                        // move from organizer's reserved to project free
                        let _ = T::Currency::repatriate_reserved(&camp.organizer, &proj, share, frame_support::traits::BalanceStatus::Free);
                    }
                }
            }

            camp.finalized = true;
            Campaigns::<T>::insert(id, camp);
            Self::deposit_event(Event::Finalized { id });
            Ok(())
        }
    }

    impl<T: Config> Pallet<T> {
        pub fn escrow_account_id() -> T::AccountId {
            T::PalletId::get().into_account_truncating()
        }
    }
}
