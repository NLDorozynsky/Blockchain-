
# Quadratic Funding — Substrate Pallet + Rust Simulator

This repo includes:

1) **`pallet-quadratic-funding`** — a FRAME pallet scaffold implementing Quadratic Funding (QF) mechanics
   (campaigns, donations, and matching from a reserved pool). Intended to be added to a Substrate runtime.

2) **`qf-sim`** — a **standalone Rust CLI** that demonstrates the QF allocation algorithm from a JSON scenario,
   so reviewers can run something immediately without a Substrate node.

> The pallet is a clean starting point and should compile once added to a Substrate node template matching the
> specified dependency versions. The CLI builds on stable Rust.

## Quick start (CLI)
```bash
cd qf-sim
cargo run -- -i examples/simple.json
```

## Add the pallet to a Substrate runtime
- Copy `pallet-quadratic-funding` into your node workspace and add it to the runtime's `Cargo.toml` and `construct_runtime!`.
- The pallet uses a `Currency` and a `PalletId` account to hold donations and disperse allocations at `finalize`.
- See doc comments in the pallet `lib.rs` for integration notes.
