# Next.js UI for CP-AMM + TWAP
`npm run dev` to start. Paste deployed addresses and interact via MetaMask.
