import { useEffect, useMemo, useState } from "react";
import { ethers } from "ethers";
import pairAbi from "./abi/CPAMMPair.json";
import routerAbi from "./abi/SimpleRouter.json";
import oracleAbi from "./abi/SimpleTWAPOracle.json";

export default function Home() {
  const [provider, setProvider] = useState<ethers.BrowserProvider>();
  const [signer, setSigner] = useState<ethers.Signer>();
  const [pairAddr, setPairAddr] = useState<string>("");
  const [routerAddr, setRouterAddr] = useState<string>("");
  const [oracleAddr, setOracleAddr] = useState<string>("");
  const [tokenIn, setTokenIn] = useState<string>("");
  const [tokenOut, setTokenOut] = useState<string>("");
  const [amountIn, setAmountIn] = useState<string>("1.0");
  const [reserves, setReserves] = useState<{r0:string,r1:string}|null>(null);
  const [spotOut, setSpotOut] = useState<string>("");

  useEffect(() => {
    if ((window as any).ethereum) {
      const p = new ethers.BrowserProvider((window as any).ethereum);
      setProvider(p);
      p.send("eth_requestAccounts", []).then(async () => {
        setSigner(await p.getSigner());
      }).catch(()=>{});
    }
  }, []);

  const pair = useMemo(()=>{
    if (!provider || !pairAddr) return null;
    return new ethers.Contract(pairAddr, pairAbi, provider);
  }, [provider, pairAddr]);

  const router = useMemo(()=>{
    if (!signer || !routerAddr) return null;
    return new ethers.Contract(routerAddr, routerAbi, signer);
  }, [signer, routerAddr]);

  const oracle = useMemo(()=>{
    if (!provider || !oracleAddr) return null;
    return new ethers.Contract(oracleAddr, oracleAbi, provider);
  }, [provider, oracleAddr]);

  async function refresh() {
    if (!pair) return;
    const [r0, r1] = await pair.getReserves();
    setReserves({ r0: r0.toString(), r1: r1.toString() });
    if (tokenIn && tokenOut) {
      const t0 = await pair.token0();
      const amountWei = ethers.parseEther(amountIn || "0");
      let out: bigint = 0n;
      if (tokenIn.toLowerCase() === t0.toLowerCase()) {
        out = await router?.getAmountOut?.(amountWei, r0, r1);
      } else {
        out = await router?.getAmountOut?.(amountWei, r1, r0);
      }
      setSpotOut(ethers.formatEther(out || 0n));
    }
  }

  async function doSwap() {
    if (!router || !pair) return;
    const amountWei = ethers.parseEther(amountIn || "0");
    const minOut = 0n;
    const tx = await router.swapExactTokensForTokens(pairAddr, tokenIn, tokenOut, amountWei, minOut, await signer?.getAddress());
    await tx.wait();
    await refresh();
  }

  async function readTWAP() {
    if (!oracle) return;
    const avg = await oracle.priceAverageE18();
    alert(`TWAP price (scaled 1e18): ${avg.toString()}`);
  }

  return (
    <main style={{maxWidth:820, margin:"40px auto", fontFamily:"ui-sans-serif"}}>
      <h1>Constant-Product AMM + TWAP Oracle</h1>
      <p style={{color:"#666"}}>Paste your deployed addresses to interact. Use the Foundry deploy script or your own deployment.</p>

      <div style={{display:"grid", gap:10, gridTemplateColumns:"1fr 1fr"}}>
        <label>Pair address <input value={pairAddr} onChange={e=>setPairAddr(e.target.value)} style={{width:"100%"}}/></label>
        <label>Router address <input value={routerAddr} onChange={e=>setRouterAddr(e.target.value)} style={{width:"100%"}}/></label>
        <label>Oracle address <input value={oracleAddr} onChange={e=>setOracleAddr(e.target.value)} style={{width:"100%"}}/></label>
        <label>Token In <input value={tokenIn} onChange={e=>setTokenIn(e.target.value)} style={{width:"100%"}}/></label>
        <label>Token Out <input value={tokenOut} onChange={e=>setTokenOut(e.target.value)} style={{width:"100%"}}/></label>
        <label>Amount In <input value={amountIn} onChange={e=>setAmountIn(e.target.value)} style={{width:"100%"}}/></label>
      </div>

      <div style={{marginTop:16, display:"flex", gap:10}}>
        <button onClick={refresh}>Refresh</button>
        <button onClick={doSwap} disabled={!router}>Swap (via Router)</button>
        <button onClick={readTWAP}>Read TWAP</button>
      </div>

      <div style={{marginTop:16}}>
        <h3>Reserves</h3>
        <pre>{JSON.stringify(reserves, null, 2)}</pre>
        <h3>Spot quote (approx)</h3>
        <pre>{spotOut}</pre>
      </div>
    </main>
  );
}
