# Constant-Product AMM + TWAP Oracle (+ Next.js UI)

This monorepo contains:
- `contracts/` — Foundry project with a constant-product AMM pair, a minimal Router, and a TWAP Oracle.
- `web/` — Next.js UI to interact with the contracts (connect with MetaMask).

## Contracts quick start
```bash
cd contracts
forge install openzeppelin/openzeppelin-contracts foundry-rs/forge-std
forge build && forge test -vv
```

## Web quick start
```bash
cd web
npm i
npm run dev
```

Deploy contracts (see `contracts/script/Deploy.s.sol`) then paste the addresses into the UI.
