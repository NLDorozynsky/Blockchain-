# Contracts — Constant-Product AMM + TWAP Oracle (Foundry)

Includes:
- `CPAMMPair.sol` — constant product AMM pair (Uniswap V2 style), tracks price cumulatives for TWAP
- `SimpleRouter.sol` — helper for swapExactTokensForTokens
- `SimpleTWAPOracle.sol` — pull-based TWAP oracle using cumulative prices
- `MockERC20.sol` — mintable testing token

## Quick start
```bash
forge install openzeppelin/openzeppelin-contracts foundry-rs/forge-std
forge build
forge test -vv
```
