
import { ethers } from "hardhat";
import { expect } from "chai";
async function sign(wallet:any, from:string, to:string, amount:bigint, nonce:bigint){
  const hash = ethers.keccak256(ethers.solidityPacked(["string","address","address","uint256","uint256"],["L2TX",from,to,amount,nonce]));
  return wallet.signMessage(ethers.getBytes(hash));
}
describe("MinimalOptimisticRollup", function(){
  it("finalize unchallenged", async()=>{
    const [admin, a, b] = await ethers.getSigners();
    const F = await ethers.getContractFactory("MinimalOptimisticRollup");
    const roll = await F.deploy(ethers.parseEther("0.1"), 5);
    await roll.waitForDeployment();
    await (await roll.connect(a).deposit({ value: ethers.parseEther("1.0") })).wait();
    const from=[await a.getAddress()], to=[await b.getAddress()], amount=[ethers.parseEther("0.2")], nonce=[1n];
    const sig=[await sign(a, from[0], to[0], amount[0], nonce[0])];
    await (await roll.connect(admin).proposeBatch(from,to,amount,nonce,sig,{value:ethers.parseEther("0.1")})).wait();
    await ethers.provider.send("evm_increaseTime",[6]); await ethers.provider.send("evm_mine",[]);
    await expect(roll.finalizeBatch(1,from,to,amount,nonce,sig)).to.emit(roll,"BatchFinalized");
  });
});
