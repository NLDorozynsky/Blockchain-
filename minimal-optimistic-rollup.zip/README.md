# Minimal Optimistic Rollup — Solidity/TypeScript
