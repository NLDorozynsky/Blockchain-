
import { ethers } from "hardhat";
async function sign(wallet:any, from:string, to:string, amount:bigint, nonce:bigint){
  const hash = ethers.keccak256(ethers.solidityPacked(["string","address","address","uint256","uint256"],["L2TX",from,to,amount,nonce]));
  return wallet.signMessage(ethers.getBytes(hash));
}
async function main(){
  const [deployer, a, b] = await ethers.getSigners();
  const Roll = await ethers.getContractFactory("MinimalOptimisticRollup");
  const roll = await Roll.deploy(ethers.parseEther("0.1"), 10);
  await roll.waitForDeployment();
  console.log("Deployed", await roll.getAddress());

  await (await roll.connect(a).deposit({ value: ethers.parseEther("1.0") })).wait();
  const from=[await a.getAddress()], to=[await b.getAddress()], amount=[ethers.parseEther("0.2")], nonce=[1n];
  const sig=[await sign(a, from[0], to[0], amount[0], nonce[0])];
  const bond=ethers.parseEther("0.1");
  const rc=await (await roll.proposeBatch(from,to,amount,nonce,sig,{value:bond})).wait();
  const id = rc!.logs.find((l:any)=>l.fragment?.name==="BatchProposed")?.args?.[0] ?? 1n;
  await ethers.provider.send("evm_increaseTime",[11]); await ethers.provider.send("evm_mine",[]);
  await (await roll.finalizeBatch(id,from,to,amount,nonce,sig)).wait();
  console.log("A bal", (await roll.balances(from[0])).toString(), "B bal", (await roll.balances(to[0])).toString());
}
main().catch((e)=>{console.error(e);process.exit(1)});
