
use anyhow::Result;
use clap::{Parser, Subcommand};
use rand::{Rng, SeedableRng};
use rand_chacha::ChaCha20Rng;

#[derive(Parser, Debug)]
#[command(name="das-demo")]
struct Cli {
    #[command(subcommand)]
    cmd: Cmd,
}

#[derive(Subcommand, Debug)]
enum Cmd {
    Simulate {
        #[arg(long, default_value="256")]
        n: usize,
        #[arg(long, default_value="128")]
        k: usize,
        #[arg(long)]
        missing_frac: Option<f64>,
        #[arg(long)]
        missing: Option<usize>,
        #[arg(long, default_value="30")]
        samples: usize,
        #[arg(long, default_value="50")]
        validators: usize,
        #[arg(long, default_value="20000")]
        trials: usize,
        #[arg(long, default_value="42")]
        seed: u64,
    },
    Erasure {
        #[arg(long, default_value="20")]
        k: usize,
        #[arg(long, default_value="10")]
        m: usize,
        #[arg(long, default_value="1024")]
        shard_len: usize,
        #[arg(long, default_value="7")]
        seed: u64,
    },
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    match cli.cmd {
        Cmd::Simulate { n, k, missing_frac, missing, samples, validators, trials, seed } => {
            simulate(n, k, missing_frac, missing, samples, validators, trials, seed)?;
        }
        Cmd::Erasure { k, m, shard_len, seed } => {
            erasure(k, m, shard_len, seed)?;
        }
    }
    Ok(())
}

fn simulate(n: usize, k: usize, missing_frac: Option<f64>, missing_abs: Option<usize>, samples: usize, validators: usize, trials: usize, seed: u64) -> Result<()> {
    assert!(k <= n);
    let h = match (missing_abs, missing_frac) {
        (Some(m), _) => m,
        (None, Some(frac)) => ((n as f64) * frac).round() as usize,
        (None, None) => ((n as f64) * 0.1).round() as usize,
    };
    assert!(h <= n);
    let p_missing = (h as f64) / (n as f64);
    let approx = 1.0 - (1.0 - p_missing).powf((samples * validators) as f64);

    let mut rng = ChaCha20Rng::seed_from_u64(seed);
    let mut detected: usize = 0;

    for _ in 0..trials {
        let mut hit = false;
        for _v in 0..validators {
            for _s in 0..samples {
                if rng.gen::<f64>() < p_missing {
                    hit = true; break;
                }
            }
            if hit { break; }
        }
        if hit { detected += 1; }
    }
    let empirical = (detected as f64) / (trials as f64);
    println!("n={} k={} parity={} missing={} p={:.4}", n, k, n-k, h, p_missing);
    println!("samples/validator={} validators={} trials={}", samples, validators, trials);
    println!("Detection: empirical={:.6} approx={:.6}", empirical, approx);
    Ok(())
}

fn erasure(k: usize, m: usize, shard_len: usize, seed: u64) -> Result<()> {
    use rand::RngCore;
    use reed_solomon_erasure::galois_8::ReedSolomon;
    let n = k + m;
    let mut rng = ChaCha20Rng::seed_from_u64(seed);
    let mut data = vec![0u8; k * shard_len];
    rng.fill_bytes(&mut data);
    let mut shards: Vec<Vec<u8>> = Vec::with_capacity(n);
    for i in 0..k {
        let start = i * shard_len;
        shards.push(data[start..start+shard_len].to_vec());
    }
    for _ in 0..m { shards.push(vec![0u8; shard_len]); }
    let rse = ReedSolomon::new(k, m).unwrap();
    rse.encode(&mut shards).unwrap();
    // lose up to min(3,m) shards
    let lost = std::cmp::min(m, 3);
    let mut lost_idxs = Vec::new();
    while lost_idxs.len() < lost {
        let idx = rng.gen_range(0..n);
        if !lost_idxs.contains(&idx) { lost_idxs.push(idx); }
    }
    let mut maybe: Vec<Option<Vec<u8>>> = shards.into_iter().map(Some).collect();
    for i in &lost_idxs { maybe[*i] = None; }
    let mut refs: Vec<Option<&mut [u8]>> = maybe.iter_mut().map(|o| o.as_mut().map(|v| v.as_mut_slice())).collect();
    rse.reconstruct(&mut refs).unwrap();
    println!("Erasure OK with lost indexes {:?}", lost_idxs);
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn rt() { erasure(6, 3, 256, 123).unwrap(); }
}
