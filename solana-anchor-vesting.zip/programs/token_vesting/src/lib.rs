
use anchor_lang::prelude::*;
use anchor_spl::associated_token::AssociatedToken;
use anchor_spl::token::{self, Mint, Token, TokenAccount, Transfer};

declare_id!("Fg6PaFpoGXkYsidMpWxqSWYF5E1Z3Z3i1Qz4dS9Z9QZg");

#[program]
pub mod token_vesting {
    use super::*;

    pub fn initialize_vesting(
        ctx: Context<InitializeVesting>,
        start_ts: i64,
        cliff_ts: i64,
        end_ts: i64,
        total_amount: u64,
        is_revocable: bool,
    ) -> Result<()> {
        require!(start_ts <= cliff_ts && cliff_ts <= end_ts, VestingError::InvalidSchedule);
        require!(total_amount > 0, VestingError::ZeroAmount);

        let v = &mut ctx.accounts.vesting;
        v.beneficiary = ctx.accounts.beneficiary.key();
        v.mint = ctx.accounts.mint.key();
        v.start_ts = start_ts;
        v.cliff_ts = cliff_ts;
        v.end_ts = end_ts;
        v.total_amount = total_amount;
        v.claimed_amount = 0;
        v.is_revocable = is_revocable;
        v.cancel_authority = ctx.accounts.cancel_authority.key();
        v.bump = *ctx.bumps.get("vesting").unwrap();

        let cpi_accounts = Transfer { from: ctx.accounts.funder_token.to_account_info(), to: ctx.accounts.vault.to_account_info(), authority: ctx.accounts.funder.to_account_info() };
        let cpi_ctx = CpiContext::new(ctx.accounts.token_program.to_account_info(), cpi_accounts);
        token::transfer(cpi_ctx, total_amount)?;
        Ok(())
    }
    pub fn claim(ctx: Context<Claim>) -> Result<()> {
        let now = Clock::get()?.unix_timestamp;
        let v = &mut ctx.accounts.vesting;
        let vested = vested_amount(v, now)?;
        require!(vested >= v.claimed_amount, VestingError::Math);
        let claimable = vested - v.claimed_amount;
        require!(claimable > 0, VestingError::NothingToClaim);
        let seeds: &[&[u8]] = &[b"vesting", v.beneficiary.as_ref(), v.mint.as_ref(), &v.start_ts.to_le_bytes(), &[v.bump]];
        let signer = &[seeds];
        let cpi_accounts = Transfer { from: ctx.accounts.vault.to_account_info(), to: ctx.accounts.beneficiary_token.to_account_info(), authority: ctx.accounts.vesting.to_account_info() };
        let cpi_ctx = CpiContext::new_with_signer(ctx.accounts.token_program.to_account_info(), cpi_accounts, signer);
        token::transfer(cpi_ctx, claimable)?;
        v.claimed_amount = v.claimed_amount.checked_add(claimable).ok_or(VestingError::Math)?;
        Ok(())
    }
    pub fn cancel(ctx: Context<Cancel>) -> Result<()> {
        let now = Clock::get()?.unix_timestamp;
        let v = &mut ctx.accounts.vesting;
        require!(v.is_revocable, VestingError::NotRevocable);
        require_keys_eq!(v.cancel_authority, ctx.accounts.cancel_authority.key(), VestingError::Unauthorized);
        let vested = vested_amount(v, now)?;
        let due = vested.saturating_sub(v.claimed_amount);
        let unvested = v.total_amount.saturating_sub(vested);
        let seeds: &[&[u8]] = &[b"vesting", v.beneficiary.as_ref(), v.mint.as_ref(), &v.start_ts.to_le_bytes(), &[v.bump]];
        let signer = &[seeds];
        if due > 0 {
            let a = Transfer { from: ctx.accounts.vault.to_account_info(), to: ctx.accounts.beneficiary_token.to_account_info(), authority: ctx.accounts.vesting.to_account_info() };
            token::transfer(CpiContext::new_with_signer(ctx.accounts.token_program.to_account_info(), a, signer), due)?;
        }
        if unvested > 0 {
            let a = Transfer { from: ctx.accounts.vault.to_account_info(), to: ctx.accounts.refund_token.to_account_info(), authority: ctx.accounts.vesting.to_account_info() };
            token::transfer(CpiContext::new_with_signer(ctx.accounts.token_program.to_account_info(), a, signer), unvested)?;
        }
        v.claimed_amount = v.total_amount;
        Ok(())
    }
}

fn vested_amount(v: &Vesting, now: i64) -> Result<u64> {
    if now < v.cliff_ts { return Ok(0); }
    if now >= v.end_ts { return Ok(v.total_amount); }
    let elapsed = (now - v.cliff_ts) as u128;
    let duration = (v.end_ts - v.cliff_ts) as u128;
    let total = v.total_amount as u128;
    let vested = total.checked_mul(elapsed).ok_or(VestingError::Math)? / duration;
    Ok(vested as u64)
}

#[derive(Accounts)]
#[instruction(start_ts: i64)]
pub struct InitializeVesting<'info> {
    #[account(mut)] pub funder: Signer<'info>,
    /// CHECK: public key only
    pub beneficiary: UncheckedAccount<'info>,
    pub mint: Account<'info, Mint>,
    #[account(init, payer = funder, space = 8 + Vesting::SIZE, seeds = [b"vesting", beneficiary.key().as_ref(), mint.key().as_ref(), &start_ts.to_le_bytes()], bump)]
    pub vesting: Account<'info, Vesting>,
    #[account(init, payer = funder, associated_token::mint = mint, associated_token::authority = vesting)]
    pub vault: Account<'info, TokenAccount>,
    #[account(mut, constraint = funder_token.mint == mint.key())]
    pub funder_token: Account<'info, TokenAccount>,
    /// CHECK: public key only
    pub cancel_authority: UncheckedAccount<'info>,
    pub system_program: Program<'info, System>,
    pub token_program: Program<'info, Token>,
    pub associated_token_program: Program<'info, AssociatedToken>,
    pub rent: Sysvar<'info, Rent>,
}

#[derive(Accounts)]
pub struct Claim<'info> {
    #[account(mut)] pub beneficiary: Signer<'info>,
    #[account(has_one = beneficiary @ VestingError::Unauthorized, has_one = mint)]
    pub vesting: Account<'info, Vesting>,
    #[account(mut, constraint = vault.owner == vesting.key(), constraint = vault.mint == mint.key())]
    pub vault: Account<'info, TokenAccount>,
    #[account(mut, constraint = beneficiary_token.owner == beneficiary.key(), constraint = beneficiary_token.mint == mint.key())]
    pub beneficiary_token: Account<'info, TokenAccount>,
    pub mint: Account<'info, Mint>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct Cancel<'info> {
    pub cancel_authority: Signer<'info>,
    #[account(has_one = mint)]
    pub vesting: Account<'info, Vesting>,
    #[account(mut, constraint = vault.owner == vesting.key(), constraint = vault.mint == mint.key())]
    pub vault: Account<'info, TokenAccount>,
    #[account(mut, constraint = beneficiary_token.owner == vesting.beneficiary, constraint = beneficiary_token.mint == mint.key())]
    pub beneficiary_token: Account<'info, TokenAccount>,
    #[account(mut, constraint = refund_token.owner == cancel_authority.key(), constraint = refund_token.mint == mint.key())]
    pub refund_token: Account<'info, TokenAccount>,
    pub mint: Account<'info, Mint>,
    pub token_program: Program<'info, Token>,
}

#[account]
pub struct Vesting {
    pub beneficiary: Pubkey,
    pub mint: Pubkey,
    pub start_ts: i64,
    pub cliff_ts: i64,
    pub end_ts: i64,
    pub total_amount: u64,
    pub claimed_amount: u64,
    pub is_revocable: bool,
    pub cancel_authority: Pubkey,
    pub bump: u8,
}
impl Vesting { pub const SIZE: usize = 32+32+8+8+8+8+8+1+32+1; }

#[error_code]
pub enum VestingError {
    #[msg("Invalid vesting schedule")] InvalidSchedule,
    #[msg("Zero amount")] ZeroAmount,
    #[msg("Math error")] Math,
    #[msg("Nothing to claim")] NothingToClaim,
    #[msg("Unauthorized")] Unauthorized,
    #[msg("Not revocable")] NotRevocable,
}
