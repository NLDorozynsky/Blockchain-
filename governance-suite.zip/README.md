# On-chain Governance Suite (Governor/Timelock/Treasury) — Solidity/TypeScript

A minimal yet complete OpenZeppelin-based governance setup:
- **GovernanceToken** (ERC20Votes)
- **TimelockController**
- **MyGovernor** (Governor + CountingSimple + Votes + Quorum + TimelockControl)
- **Treasury** (Ownable; ownership moved to Timelock so only governance can `release` funds)

Comes with **TypeScript scripts** for the end-to-end proposal flow and **tests** that exercise
propose → vote → queue → execute against a local Hardhat network.

> Educational scaffold — not audited.

## Quick start
```bash
npm i
npx hardhat test

# Deploy locally
npx hardhat run scripts/deploy.ts

# Then (in separate steps) propose -> vote -> queue -> execute
npx hardhat run scripts/propose_transfer.ts
npx hardhat run scripts/queue.ts
npx hardhat run scripts/execute.ts
```
