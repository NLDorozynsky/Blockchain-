import { ethers } from "hardhat";
import { loadAddresses } from "./_common";
import fs from "fs";

async function main() {
  const { governor, treasury } = loadAddresses();
  const { proposalId, description } = JSON.parse(fs.readFileSync("./proposal.json","utf-8"));
  const descriptionHash = ethers.id(description);

  // For queue we need the same args as propose
  const iface = new ethers.Interface([ "function release(address to, uint256 amount)" ]);
  const [proposer] = await ethers.getSigners();
  const calldata = iface.encodeFunctionData("release", [await proposer.getAddress(), ethers.parseEther("0.25")]);

  const gov = await ethers.getContractAt("MyGovernor", governor);
  const tx = await gov.queue([treasury], [0], [calldata], descriptionHash);
  await tx.wait();
  console.log("Queued:", proposalId);
}

main().catch((e) => { console.error(e); process.exit(1); });
