import { ethers } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deployer:", await deployer.getAddress());

  // 1) Governance token (delegate to deployer for voting power)
  const Token = await ethers.getContractFactory("GovernanceToken");
  const token = await Token.deploy();
  await token.waitForDeployment();
  await (await token.delegate(await deployer.getAddress())).wait();
  console.log("Token:", await token.getAddress());

  // 2) Timelock (minDelay=1s; proposers: governor later; executors: open to everyone)
  const minDelay = 1; // seconds
  const Timelock = await ethers.getContractFactory("TimelockController");
  const timelock = await Timelock.deploy(minDelay, [], []);
  await timelock.waitForDeployment();
  console.log("Timelock:", await timelock.getAddress());

  // 3) Governor
  const votingDelay = 1;  // blocks
  const votingPeriod = 10; // blocks
  const proposalThreshold = 0;
  const quorumBps = 400; // 4%
  const Gov = await ethers.getContractFactory("MyGovernor");
  const governor = await Gov.deploy(await token.getAddress(), await timelock.getAddress(), votingDelay, votingPeriod, proposalThreshold, quorumBps);
  await governor.waitForDeployment();
  console.log("Governor:", await governor.getAddress());

  // Roles: grant PROPOSER to governor, EXECUTOR to everyone (address(0)), and revoke deployer as admin if desired
  const PROPOSER_ROLE = await timelock.PROPOSER_ROLE();
  const EXECUTOR_ROLE = await timelock.EXECUTOR_ROLE();
  const CANCELLER_ROLE = await timelock.CANCELLER_ROLE?.().catch(()=>null);

  await (await timelock.grantRole(PROPOSER_ROLE, await governor.getAddress())).wait();
  await (await timelock.grantRole(EXECUTOR_ROLE, ethers.ZeroAddress)).wait();
  if (CANCELLER_ROLE) { await (await timelock.grantRole(CANCELLER_ROLE, await governor.getAddress())).wait(); }

  // 4) Treasury (owned by timelock)
  const Treasury = await ethers.getContractFactory("Treasury");
  const treasury = await Treasury.deploy(await timelock.getAddress());
  await treasury.waitForDeployment();
  console.log("Treasury:", await treasury.getAddress());

  // seed treasury with 1 ETH
  await deployer.sendTransaction({ to: await treasury.getAddress(), value: ethers.parseEther("1.0") });

  // Save addresses
  const out = {
    token: await token.getAddress(),
    timelock: await timelock.getAddress(),
    governor: await governor.getAddress(),
    treasury: await treasury.getAddress()
  };
  console.log(JSON.stringify(out, null, 2));
}

main().catch((e) => { console.error(e); process.exit(1); });
