import { ethers } from "hardhat";
import fs from "fs";
import { loadAddresses } from "./_common";

async function main() {
  const [proposer] = await ethers.getSigners();
  const { governor, treasury } = loadAddresses();

  const iface = new ethers.Interface([ "function release(address to, uint256 amount)" ]);
  const calldata = iface.encodeFunctionData("release", [await proposer.getAddress(), ethers.parseEther("0.25")]);

  const description = "Release 0.25 ETH to proposer from Treasury";
  const tx = await (await ethers.getContractAt("MyGovernor", governor)).propose(
    [treasury],
    [0],
    [calldata],
    description
  );
  const rc = await tx.wait();
  const ev = rc!.logs.find((l:any)=> l.fragment?.name === "ProposalCreated");
  const proposalId = ev ? ev.args.proposalId : null;
  console.log("Proposed:", proposalId?.toString());
  if (proposalId) fs.writeFileSync("./proposal.json", JSON.stringify({ proposalId: proposalId.toString(), description }, null, 2));
}

main().catch((e) => { console.error(e); process.exit(1); });
