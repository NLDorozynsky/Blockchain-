import fs from "fs";
export function loadAddresses() {
  const p = "./deploy.json";
  const txt = fs.readFileSync(p, "utf-8");
  return JSON.parse(txt);
}
