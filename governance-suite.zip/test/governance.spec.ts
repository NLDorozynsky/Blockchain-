import { expect } from "chai";
import { ethers } from "hardhat";

describe("Governance Suite", function () {
  it("end-to-end proposal lifecycle", async () => {
    const [deployer, voter] = await ethers.getSigners();

    // Token + delegate
    const Token = await ethers.getContractFactory("GovernanceToken");
    const token = await Token.deploy();
    await token.waitForDeployment();
    await (await token.delegate(await deployer.getAddress())).wait();
    await (await token.transfer(await voter.getAddress(), ethers.parseEther("1000"))).wait();
    await (await token.connect(voter).delegate(await voter.getAddress())).wait();

    // Timelock
    const Timelock = await ethers.getContractFactory("TimelockController");
    const timelock = await Timelock.deploy(1, [], []);
    await timelock.waitForDeployment();

    // Governor
    const Gov = await ethers.getContractFactory("MyGovernor");
    const governor = await Gov.deploy(await token.getAddress(), await timelock.getAddress(), 1, 5, 0, 400);
    await governor.waitForDeployment();

    // Roles
    const PROPOSER_ROLE = await timelock.PROPOSER_ROLE();
    const EXECUTOR_ROLE = await timelock.EXECUTOR_ROLE();
    await (await timelock.grantRole(PROPOSER_ROLE, await governor.getAddress())).wait();
    await (await timelock.grantRole(EXECUTOR_ROLE, ethers.ZeroAddress)).wait();

    // Treasury owned by timelock
    const Treasury = await ethers.getContractFactory("Treasury");
    const treasury = await Treasury.deploy(await timelock.getAddress());
    await treasury.waitForDeployment();

    await deployer.sendTransaction({ to: await treasury.getAddress(), value: ethers.parseEther("1.0") });

    // Build proposal to release 0.25 ETH to voter
    const iface = new ethers.Interface([ "function release(address to, uint256 amount)" ]);
    const calldata = iface.encodeFunctionData("release", [await voter.getAddress(), ethers.parseEther("0.25")]);
    const proposalDescription = "Release 0.25 ETH to voter";

    const proposeTx = await governor.propose([await treasury.getAddress()], [0], [calldata], proposalDescription);
    const proposeRc = await proposeTx.wait();
    const event = proposeRc!.logs.find((l:any)=> l.fragment?.name === "ProposalCreated");
    const proposalId = event?.args?.proposalId;

    // Move past votingDelay (1 block)
    await ethers.provider.send("evm_mine", []);

    // Cast vote (for)
    await (await governor.connect(voter).castVote(proposalId, 1)).wait();

    // Advance voting period (5 blocks)
    for (let i=0;i<6;i++) await ethers.provider.send("evm_mine", []);

    // Queue
    const descriptionHash = ethers.id(proposalDescription);
    await (await governor.queue([await treasury.getAddress()], [0], [calldata], descriptionHash)).wait();

    // Increase time to satisfy timelock delay
    await ethers.provider.send("evm_increaseTime", [2]);
    await ethers.provider.send("evm_mine", []);

    // Execute
    const balBefore = await ethers.provider.getBalance(await voter.getAddress());
    await (await governor.execute([await treasury.getAddress()], [0], [calldata], descriptionHash)).wait();
    const balAfter = await ethers.provider.getBalance(await voter.getAddress());
    expect(balAfter - balBefore).to.be.greaterThan(0n);
  });
});
