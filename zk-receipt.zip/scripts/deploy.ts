import { ethers } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deployer:", await deployer.getAddress());

  // Deploy MockVerifier
  const Mock = await ethers.getContractFactory("MockVerifier");
  const mock = await Mock.deploy();
  await mock.waitForDeployment();

  // Deploy ZKReceipt
  const ZK = await ethers.getContractFactory("ZKReceipt");
  const zk = await ZK.deploy(await mock.getAddress());
  await zk.waitForDeployment();

  console.log("MockVerifier:", await mock.getAddress());
  console.log("ZKReceipt   :", await zk.getAddress());
}

main().catch((e) => { console.error(e); process.exit(1); });
