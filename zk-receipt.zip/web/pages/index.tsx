import { useEffect, useMemo, useState } from 'react';
import { ethers } from 'ethers';

export default function Home() {
  const [addr, setAddr] = useState<string>('');
  const [limit, setLimit] = useState<string>('1000');
  const [amount, setAmount] = useState<string>('350');
  const [meta, setMeta] = useState<string>('merchant:demo;timestamp:...');
  const [contractAddr, setContractAddr] = useState<string>('');

  useEffect(() => {
    setContractAddr(process.env.NEXT_PUBLIC_RECEIPT_ADDRESS || '');
  }, []);

  async function connect() {
    // @ts-ignore
    const provider = new ethers.BrowserProvider(window.ethereum);
    await provider.send('eth_requestAccounts', []);
    const signer = await provider.getSigner();
    setAddr(await signer.getAddress());
  }

  async function submitMock() {
    if (!contractAddr) return alert('Set NEXT_PUBLIC_RECEIPT_ADDRESS');
    // mock proof + pubSignals: with real verifier, transform proof.json/public.json accordingly
    const proof = '0x';
    const pubSignals = [BigInt(limit)];
    const metaHash = ethers.keccak256(ethers.toUtf8Bytes(meta));
    // @ts-ignore
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const abi = [
      "function submitReceipt(bytes proof, uint256[] pubSignals, bytes32 metaHash)"
    ];
    const c = new ethers.Contract(contractAddr, abi, signer);
    const tx = await c.submitReceipt(proof, pubSignals, metaHash);
    await tx.wait();
    alert('Submitted!');
  }

  return (
    <main style={{maxWidth:860, margin:'40px auto', fontFamily:'ui-sans-serif'}}>
      <h1>Selective-Disclosure ZK Receipt</h1>
      <p>Demo: Prove <code>amount ≤ limit</code> (toy) and submit an on-chain receipt with minimal public disclosure.</p>
      <div style={{display:'flex', gap:8, marginBottom:12}}>
        <button onClick={connect}>Connect</button>
        <span>{addr ? 'Connected: ' + addr : 'Not connected'}</span>
      </div>
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
        <label>Limit <input value={limit} onChange={e=>setLimit(e.target.value)} /></label>
        <label>Amount (private in real proof) <input value={amount} onChange={e=>setAmount(e.target.value)} /></label>
        <label style={{gridColumn:'1 / span 2'}}>Metadata (local only; hashed on-chain) <input value={meta} onChange={e=>setMeta(e.target.value)} style={{width:'100%'}}/></label>
      </div>
      <div style={{marginTop:12}}>
        <button onClick={submitMock}>Submit with Mock Verifier</button>
      </div>
      <p style={{marginTop:16, color:'#666'}}>Replace the mock verifier by generating a real Groth16 verifier with <code>snarkjs</code>, then pass real proof/public signals here.</p>
    </main>
  );
}
