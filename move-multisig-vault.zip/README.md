# Move Module: Multi-sig Vault — Move (Aptos/Sui)

This repo provides **two** Move packages implementing a multi-sig vault:

- `aptos/` — Aptos Move module `multisig::multisig_vault` holding **AptosCoin** with proposal/approval/execute.
- `sui/` — Sui Move module `multisig::vault` holding **SUI** with approvals supplied in the call.

They are intentionally minimal for learning; extend with events, more proposal types, and access checks for production.
