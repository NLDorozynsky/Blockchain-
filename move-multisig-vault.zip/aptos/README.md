# Aptos Move: Multi-sig Vault (AptosCoin)

A simple multi-signature vault that holds **AptosCoin** and requires a threshold of member approvals
to execute a transfer proposal.

## Layout
- `sources/multisig_vault.move` — module `multisig::multisig_vault`
- `Move.toml` — package config (pulls Aptos framework from Git)

## Quick start
```bash
# Init your account if needed
aptos init

# Compile
aptos move compile --package-dir .

# Publish (devnet/testnet/mainnet as configured)
aptos move publish --package-dir .

# After publish, call entry functions with aptos CLI or a frontend:
# - init_vault(members, threshold)
# - deposit(coin)
# - propose_transfer(to, amount)
# - approve(id)
```
