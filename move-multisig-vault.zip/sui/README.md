# Sui Move: Multi-sig Vault (SUI)

A minimal Sui Move **Vault** object that holds SUI and requires `threshold` approvals to transfer.

## Layout
- `sources/multisig.move` — module `multisig::vault`
- `Move.toml` — Sui package config

## Quick start
```bash
# Build
sui move build

# Test (if you add tests)
sui move test

# Publish (devnet/localnet as configured)
sui client publish --gas-budget 100000000
```
