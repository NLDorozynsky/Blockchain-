# ERC-4626 Yield Vault — Solidity/Foundry

A clean ERC-4626 vault that accrues yield via external asset inflow and a `harvest()` hook.
It uses OpenZeppelin's ERC-4626 + ERC20 and mint-on-harvest **fee shares** (performance fee).

> Educational scaffold — not audited or production ready.

## Quick start
```bash
# Install dependencies
forge install openzeppelin/openzeppelin-contracts foundry-rs/forge-std

# Build & test
forge build
forge test -vv

# Deploy (local anvil)
anvil &
forge script script/Deploy.s.sol --broadcast --rpc-url http://127.0.0.1:8545
```
