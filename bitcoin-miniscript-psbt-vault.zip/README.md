# Bitcoin Miniscript PSBT Vault — Rust/Python

A practical scaffold showing how to design and work with a **vault-like** Miniscript policy,
derive addresses, and validate PSBTs. Includes:

- **Rust CLI** (`rust/psbt-vault`): parse a **Miniscript descriptor**, print policy,
  derive the **P2WSH address**, and sanity‑check PSBTs against the descriptor.
- **Python tools** (`python/scripts`): create **funding** and **spending** PSBT templates with
  `python-bitcointx`, and a simple **WIF** signer for legacy single‑sig parts (toy).

> Educational only — not production. No key management, HSM, or full validation.
> Use on **testnet/regtest** while learning.

## Example vault policy

Example (emergency timelock OR 2‑of‑3):

```
wsh(or(and_v(v:pk(A),older(12960)),thresh(2,pk(B),pk(C),pk(D))))
```

Meaning: **after ~90 days** (`older(12960)` at 10 min/blk), key A alone can spend; otherwise any **2‑of‑3**
of keys B, C, D can spend immediately.

## Quick start

### Rust CLI
```bash
cd rust/psbt-vault
cargo build

# 1) Show descriptor info
cargo run -- descriptor-info \\
  --descriptor "wsh(or(and_v(v:pk(0279be667...)),thresh(2,pk(02...B),pk(02...C),pk(02...D))))" \\
  --network testnet

# 2) Derive address
cargo run -- address --descriptor "<descriptor>" --network testnet

# 3) Analyze PSBT (base64 file) against descriptor
cargo run -- analyze-psbt --descriptor "<descriptor>" --psbt ./spend.psbt --network testnet
```

### Python PSBT helpers
```bash
cd python
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt

# Create a funding PSBT paying to the vault address (fill UTXO placeholders)
python scripts/fund_psbt.py --address tb1q... --txid <hex> --vout 0 --amount-sats 100000 --change tb1q...

# Create a spend PSBT from a P2WSH vault UTXO to a destination (fill scripts/witness later)
python scripts/spend_psbt.py --wsh <hex redeem script> --txid <hex> --vout 0 --value 100000 --to tb1q... --fee 500

# (Optional) Sign a single-sig input with WIF (toy)
python scripts/sign_psbt_wif.py --psbt in.psbt --wif cT... --index 0 > out.psbt
```

## What’s here

- `rust/psbt-vault`: Miniscript/descriptor parsing, address derivation, PSBT sanity checks.
- `python/scripts`: PSBT assembly helpers using **python-bitcointx**.

### Notes / TODO

- For serious use, enforce key origin paths (`[fingerprint/derivation]xpub/...` descriptors).
- Add Miniscript **satisfaction construction** for both branches (2‑of‑3 and timelock).
- Add **regtest docker** + **integration tests** spanning end‑to‑end flows.
