#!/usr/bin/env python3
"""Create a spend PSBT spending a P2WSH vault UTXO to destination (toy)."""
import argparse
from bitcointx.core import COutPoint, CTxIn, CTxOut, CTransaction, lx
from bitcointx.core.psbt import PSBT
from bitcointx.wallet import CBitcoinAddress, P2WSHBitcoinAddress
from bitcointx import select_chain_params
from bitcointx.core.script import CScript
select_chain_params('testnet')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--wsh', required=True, help='witness script hex (from descriptor)')
    ap.add_argument('--txid', required=True)
    ap.add_argument('--vout', type=int, required=True)
    ap.add_argument('--value', type=int, required=True, help='UTXO value (sats)')
    ap.add_argument('--to', required=True, help='dest address (tb1...)')
    ap.add_argument('--fee', type=int, default=500)
    args = ap.parse_args()

    wsh = bytes.fromhex(args.wsh)
    dest = CBitcoinAddress(args.to)

    txin = CTxIn(COutPoint(lx(args.txid), args.vout))
    txout = CTxOut(args.value - args.fee, dest.to_scriptPubKey())
    tx = CTransaction([txin], [txout], nVersion=2)
    psbt = PSBT.from_tx(tx)
    # Provide witness UTXO and witness_script so signers/aggregator can finalize later
    psbt.inputs[0].witness_utxo = CTxOut(args.value, P2WSHBitcoinAddress.from_redeemScript(CScript(wsh)).to_scriptPubKey())
    psbt.inputs[0].witness_script = CScript(wsh)
    print(psbt.to_base64())

if __name__ == '__main__':
    main()
