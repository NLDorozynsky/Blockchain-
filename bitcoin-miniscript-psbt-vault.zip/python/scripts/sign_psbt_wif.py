#!/usr/bin/env python3
"""(Toy) Sign a PSBT single-sig input with a WIF key (P2WPKH), writes base64 to stdout."""
import argparse, sys
from bitcointx import select_chain_params
from bitcointx.wallet import CBitcoinSecret, P2WPKHBitcoinAddress
from bitcointx.core import b2x
from bitcointx.core.psbt import PSBT
from bitcointx.core.key import CPubKey

select_chain_params('testnet')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--psbt', required=True)
    ap.add_argument('--wif', required=True)
    ap.add_argument('--index', type=int, default=0)
    args = ap.parse_args()

    with open(args.psbt, 'r') as f:
        b64 = f.read().strip()
    psbt = PSBT.from_base64(b64)

    seckey = CBitcoinSecret(args.wif)
    pub = CPubKey(seckey.pub)
    # This is a toy: only fills in partial sig for a P2WPKH template when witness_utxo/scriptPubKey match
    psbt.sign_with(seckey, [args.index])
    print(psbt.to_base64())

if __name__ == '__main__':
    main()
