#!/usr/bin/env python3
"""Create a funding PSBT paying to a given address from a single UTXO (toy)."""
import argparse
from bitcointx.core import COutPoint, CTxIn, CTxOut, CTransaction, b2x, lx, x, COIN
from bitcointx.core.psbt import PSBT
from bitcointx.wallet import CBitcoinAddress
from bitcointx import select_chain_params
select_chain_params('testnet')

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--address', required=True, help='vault p2wsh address (tb1...)')
    ap.add_argument('--txid', required=True, help='funding UTXO txid (hex)')
    ap.add_argument('--vout', required=True, type=int)
    ap.add_argument('--amount-sats', required=True, type=int, help='UTXO amount in sats')
    ap.add_argument('--change', required=False, help='change address (tb1...)')
    ap.add_argument('--fee', type=int, default=500)
    args = ap.parse_args()

    addr = CBitcoinAddress(args.address)
    txin = CTxIn(COutPoint(lx(args.txid), args.vout))
    outsats = args.amount_sats - args.fee
    if args.change:
        # 50/50 example split; adjust to your needs
        to_vault = outsats // 2
        to_change = outsats - to_vault
        txouts = [CTxOut(to_vault, addr.to_scriptPubKey()),
                  CTxOut(to_change, CBitcoinAddress(args.change).to_scriptPubKey())]
    else:
        txouts = [CTxOut(outsats, addr.to_scriptPubKey())]

    tx = CTransaction([txin], txouts, nVersion=2)
    psbt = PSBT.from_tx(tx)
    # Attach witness UTXO value for input 0
    psbt.inputs[0].witness_utxo = CTxOut(args.amount_sats, CBitcoinAddress(args.address).to_scriptPubKey())
    print(psbt.to_base64())

if __name__ == '__main__':
    main()
