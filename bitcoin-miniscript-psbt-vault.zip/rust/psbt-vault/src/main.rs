use anyhow::{anyhow, Context, Result};
use base64::Engine;
use base64::engine::general_purpose::STANDARD as b64;
use bitcoin::{Address, Network, ScriptBuf, psbt::PartiallySignedTransaction as Psbt};
use bitcoin::consensus::{deserialize};
use miniscript::{Descriptor, Segwitv0, descriptor::Wsh};
use clap::{Parser, Subcommand};
use std::fs;

#[derive(Parser)]
#[command(name="psbt-vault")]
#[command(about="Bitcoin Miniscript PSBT Vault CLI")]
struct Cli {
    #[command(subcommand)]
    cmd: Cmd,
}

#[derive(Subcommand)]
enum Cmd {
    /// Parse a Miniscript descriptor and print info
    DescriptorInfo { #[arg(long)] descriptor: String, #[arg(long, default_value="testnet")] network: String },
    /// Derive the P2WSH address from a descriptor
    Address { #[arg(long)] descriptor: String, #[arg(long, default_value="testnet")] network: String },
    /// Analyze a PSBT (base64) and sanity-check against descriptor's script
    AnalyzePsbt { #[arg(long)] descriptor: String, #[arg(long)] psbt: String, #[arg(long, default_value="testnet")] network: String },
}

fn parse_network(s: &str) -> Result<Network> {
    Ok(match s {
        "bitcoin" | "mainnet" => Network::Bitcoin,
        "testnet" => Network::Testnet,
        "signet" => Network::Signet,
        "regtest" => Network::Regtest,
        other => return Err(anyhow!("unknown network: {}", other))
    })
}

fn parse_descriptor(desc: &str) -> Result<Descriptor<bitcoin::PublicKey>> {
    let d: Descriptor<bitcoin::PublicKey> = desc.parse()?;
    Ok(d)
}

fn p2wsh_address_from_descriptor(desc: &Descriptor<bitcoin::PublicKey>, net: Network) -> Result<(Address, ScriptBuf)> {
    // Expect wsh miniscript; if not, wrap script into wsh address if possible
    match desc {
        Descriptor::Wsh(wsh) => {
            let script = wsh.script_pubkey();
            let addr = Address::from_script(&script, net).context("address from wsh script")?;
            Ok((addr, script))
        },
        other => {
            // Derive spk and an address (will be wrong policy if not wsh)
            let spk = other.script_pubkey();
            let addr = Address::from_script(&spk, net).context("address from spk")?;
            Ok((addr, spk))
        }
    }
}

fn read_psbt(path: &str) -> Result<Psbt> {
    let data = fs::read(path).context("read psbt file")?;
    // try base64 first
    let maybe = b64.decode(&data).ok();
    let raw = maybe.as_deref().unwrap_or(&data);
    let psbt: Psbt = deserialize(raw).context("deserialize psbt")?;
    Ok(psbt)
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    match cli.cmd {
        Cmd::DescriptorInfo { descriptor, network } => {
            let net = parse_network(&network)?;
            let desc = parse_descriptor(&descriptor)?;
            println!("Descriptor: {}", desc);
            println!("Descriptor (to_string no checksum): {}", desc.to_string_no_checksum());
            // Policy (if compilable)
            if let Ok(policy) = desc.sanity_check() {
                println!("Sanity: {:?}", policy);
            } else {
                println!("Sanity: failed (non-standard?)");
            }
            let (addr, spk) = p2wsh_address_from_descriptor(&desc, net)?;
            println!("ScriptPubKey: {}", spk);
            println!("Address [{}]: {}", net, addr);
        }
        Cmd::Address { descriptor, network } => {
            let net = parse_network(&network)?;
            let desc = parse_descriptor(&descriptor)?;
            let (addr, spk) = p2wsh_address_from_descriptor(&desc, net)?;
            println!("Address [{}]: {}", net, addr);
            println!("ScriptPubKey: {}", spk);
        }
        Cmd::AnalyzePsbt { descriptor, psbt, network } => {
            let net = parse_network(&network)?;
            let desc = parse_descriptor(&descriptor)?;
            let (_, expected_spk) = p2wsh_address_from_descriptor(&desc, net)?;
            let p = read_psbt(&psbt)?;
            println!("PSBT version: {}", p.version);
            for (i, inp) in p.inputs.iter().enumerate() {
                // Check witness_script or redeem_script matches descriptor's script (for P2WSH flows)
                if let Some(ws) = &inp.witness_script {
                    if ws.to_p2wsh().script_pubkey() == expected_spk {
                        println!("Input {}: matches descriptor witness_script", i);
                    } else {
                        println!("Input {}: witness_script present, but not matching descriptor", i);
                    }
                } else if let Some(rs) = &inp.redeem_script {
                    if rs.to_p2wsh().script_pubkey() == expected_spk {
                        println!("Input {}: redeem_script P2WSH matches descriptor", i);
                    } else {
                        println!("Input {}: redeem_script present, but not matching descriptor", i);
                    }
                } else {
                    println!("Input {}: no witness/redeem script to compare", i);
                }
            }
        }
    }
    Ok(())
}
