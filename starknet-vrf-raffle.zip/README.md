# StarkNet VRF Raffle — Cairo (Cairo 1 + Scarb)

A didactic **VRF-style raffle** showing how a raffle contract can consume randomness
from an external oracle. This scaffold includes:

- `Raffle` contract: lets participants buy tickets, requests randomness, and
  accepts a callback `fulfill_randomness(request_id, random)` from an oracle.
- `VRFOracle` PoC contract: an owner-controlled contract that can call the raffle's
  `fulfill_randomness` with a supplied random number (standing in for a real VRF proof).
- `IRaffle` interface for cross-contract calls.

> Educational only. Replace `VRFOracle` with a real proving/verifier system in production.

## Quick start
```bash
# Prerequisites: cairo/Scarb toolchain installed
scarb --version

# Build & run unit tests
scarb build
scarb test

# (Optional) Deploy with starkli/devnet and call `raffle::buy_ticket` then
# `vrf_oracle::fulfill_for` to pick a winner.
```

## Files
- `src/iface_raffle.cairo` — IRaffle interface
- `src/raffle.cairo` — raffle contract
- `src/vrf_oracle.cairo` — owner-only oracle PoC that calls raffle via interface

The `raffle` keeps a simple storage-backed list of participants and computes
`winner_idx = random % participants_len`.

You can extend this by:
- Replacing `VRFOracle` with an actual VRF verifier (e.g., via pedersen/ecdsa proofs),
- Allowing payments, deadlines, and multiple rounds,
- Emitting richer events and adding access controls.
