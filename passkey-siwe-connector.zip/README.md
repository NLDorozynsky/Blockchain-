# Passkey + SIWE Wallet Connector — Next.js/TypeScript

A minimal Next.js demo that combines **Passkeys (WebAuthn)** and **SIWE (Sign‑In with Ethereum)**.
It uses:
- `@simplewebauthn` for passkey registration/authentication
- `siwe` + `ethers` for Ethereum signatures
- `iron-session` for session cookies (dev‑only defaults)

> This is a teaching scaffold (no DB; in‑memory store; not production‑ready).

## Quick start
```bash
# 1) Install
npm i

# 2) Configure
cp .env.example .env.local
# Edit SESSION_PASSWORD (>=32 chars), RP_ID/ORIGIN if needed

# 3) Run
npm run dev
# open http://localhost:3000
```
- SIWE: Click "Connect & Sign", sign the SIWE message in your wallet (e.g., MetaMask).  
- Passkeys: Enter a username, click "Register", then "Login".

### Project layout
- `pages/api/siwe/*` — nonce/verify/me endpoints
- `pages/api/passkey/*` — passkey registration/auth flows
- `lib/session.ts`, `lib/withSession.ts` — iron-session helpers
- `lib/db.ts` — in-memory user/passkey store
- `pages/index.tsx` — simple UI for both flows

### Notes / TODO
- Replace in-memory store with a real DB (store passkeys, challenges, SIWE nonce/session)
- Add CSRF protection & stricter session handling
- In production, **bind SIWE domain/URI**, support chainId/network, and robust nonce replay protection
- For passkeys, ensure correct RP ID & Origin, advanced authenticator policies, and migration strategy
