
# ocstable-sim — Over-collateralized Stablecoin Simulator (Go)

Run:
```bash
go run . -i examples/simple.json
```
