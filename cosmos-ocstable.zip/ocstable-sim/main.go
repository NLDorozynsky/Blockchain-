
package main

import (
    "encoding/json"
    "errors"
    "flag"
    "fmt"
    "math"
    "os"
    "sort"
)

type Params struct {
    MinCollateralRatio  float64 `json:"mcr"`   // e.g., 1.5
    LiquidationRatio    float64 `json:"lr"`    // e.g., 1.2
    StabilityFeeAPR     float64 `json:"apr"`   // e.g., 0.05
    LiquidationPenalty  float64 `json:"pen"`   // e.g., 0.10
}

type Action struct {
    T       int     `json:"t"`     // timestep index
    Type    string  `json:"type"`  // deposit|withdraw|mint|repay
    Who     string  `json:"who"`
    Amount  float64 `json:"amount"`
}

type Scenario struct {
    Params      Params                      `json:"params"`
    InitialPrice float64                    `json:"initial_price"`
    PriceSeries []float64                   `json:"price_series"`
    Accounts    map[string]*Position        `json:"accounts"`
    Actions     []Action                    `json:"actions"`
}

type Position struct {
    Collateral float64 `json:"collateral"` // in units of collateral asset
    Debt       float64 `json:"debt"`       // in units of stablecoin
}

func cr(p Position, price float64) float64 {
    if p.Debt <= 0 { return math.Inf(1) }
    return (p.Collateral * price) / p.Debt
}

func accrueDebt(p *Position, apr float64, dtYears float64) {
    if p.Debt <= 0 { return }
    p.Debt *= (1.0 + apr*dtYears)
}

func applyAction(sc *Scenario, step int, price float64, act Action) error {
    pos, ok := sc.Accounts[act.Who]
    if !ok {
        return fmt.Errorf("unknown account: %s", act.Who)
    }
    switch act.Type {
    case "deposit":
        pos.Collateral += act.Amount
    case "withdraw":
        // check MCR after withdrawal
        if act.Amount > pos.Collateral { return errors.New("withdraw exceeds collateral") }
        tmp := *pos
        tmp.Collateral -= act.Amount
        if cr(tmp, price) < sc.Params.MinCollateralRatio {
            return errors.New("post-withdraw CR < MCR")
        }
        pos.Collateral = tmp.Collateral
    case "mint":
        // check MCR after mint
        tmp := *pos
        tmp.Debt += act.Amount
        if cr(tmp, price) < sc.Params.MinCollateralRatio {
            return errors.New("post-mint CR < MCR")
        }
        pos.Debt = tmp.Debt
    case "repay":
        if act.Amount > pos.Debt { act.Amount = pos.Debt }
        pos.Debt -= act.Amount
    default:
        return fmt.Errorf("unknown action type: %s", act.Type)
    }
    return nil
}

func liquidateIfNeeded(sc *Scenario, price float64, who string, pos *Position) (liquidated bool, detail string) {
    if pos.Debt <= 0 { return false, "" }
    if cr(*pos, price) >= sc.Params.LiquidationRatio { return false, "" }

    // sell enough collateral at price to cover Debt*(1+penalty)
    target := pos.Debt * (1.0 + sc.Params.LiquidationPenalty)
    neededCollateral := target / price
    if neededCollateral >= pos.Collateral {
        // wipe entire collateral; repay what we can
        repay := pos.Collateral * price
        pos.Collateral = 0
        pos.Debt -= math.Min(pos.Debt, repay) // if repay >= debt, debt hits zero
        detail = fmt.Sprintf("FULL (sold all). repaid=%.2f debt=%.2f", repay, pos.Debt)
    } else {
        // partial sale to fully cover target
        pos.Collateral -= neededCollateral
        pos.Debt = 0 // fully repaid (including penalty)
        detail = fmt.Sprintf("PARTIAL (sold %.4f). new_collat=%.4f", neededCollateral, pos.Collateral)
    }
    return true, detail
}

func main() {
    var input string
    flag.StringVar(&input, "i", "", "scenario JSON file")
    flag.Parse()
    if input == "" {
        fmt.Println("usage: ocstable-sim -i examples/simple.json")
        os.Exit(2)
    }
    b, err := os.ReadFile(input); if err != nil { panic(err) }
    var sc Scenario
    if err := json.Unmarshal(b, &sc); err != nil { panic(err) }

    price := sc.InitialPrice
    fmt.Printf("Params: MCR=%.2f LR=%.2f APR=%.2f PEN=%.2f\n", sc.Params.MinCollateralRatio, sc.Params.LiquidationRatio, sc.Params.StabilityFeeAPR, sc.Params.LiquidationPenalty)
    fmt.Printf("Initial price: %.2f\n\n", price)

    // index actions by timestep
    acts := map[int][]Action{}
    for _, a := range sc.Actions {
        acts[a.T] = append(acts[a.T], a)
    }

    steps := len(sc.PriceSeries)
    for t := 0; t < steps; t++ {
        price = sc.PriceSeries[t]
        fmt.Printf("=== t=%d price=%.2f ===\n", t, price)

        // 1) accrue interest for all positions for dt = 1/365 year (daily steps assumption)
        dtYears := 1.0/365.0
        for who, pos := range sc.Accounts {
            before := pos.Debt
            accrueDebt(pos, sc.Params.StabilityFeeAPR, dtYears)
            if pos.Debt != before {
                fmt.Printf("accrue %-8s debt: %.2f -> %.2f\n", who, before, pos.Debt)
            }
        }

        // 2) apply actions at this step
        if aa, ok := acts[t]; ok {
            // deterministic order by Who then Type
            sort.Slice(aa, func(i,j int) bool { 
                if aa[i].Who == aa[j].Who { return aa[i].Type < aa[j].Type }
                return aa[i].Who < aa[j].Who
            })
            for _, a := range aa {
                if err := applyAction(&sc, t, price, a); err != nil {
                    fmt.Printf("action ERROR t=%d %s: %v\n", t, fmt.Sprintf("%s/%s", a.Who, a.Type), err)
                } else {
                    fmt.Printf("action t=%d %-8s %-9s amount=%.2f\n", t, a.Who, a.Type, a.Amount)
                }
            }
        }

        // 3) liquidations
        for who, pos := range sc.Accounts {
            if liq, why := liquidateIfNeeded(&sc, price, who, pos); liq {
                fmt.Printf("LIQUIDATE %-8s -> %s\n", who, why)
            }
        }

        // 4) snapshot
        fmt.Printf("%-8s %-10s %-10s %-10s\n", "account", "collat", "debt", "CR")
        keys := make([]string, 0, len(sc.Accounts))
        for who := range sc.Accounts { keys = append(keys, who) }
        sort.Strings(keys)
        for _, who := range keys {
            p := sc.Accounts[who]
            fmt.Printf("%-8s %-10.4f %-10.2f %-10.2f\n", who, p.Collateral, p.Debt, cr(*p, price))
        }
        fmt.Println()
    }
}
