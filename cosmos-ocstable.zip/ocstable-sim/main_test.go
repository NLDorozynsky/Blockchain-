
package main

import "testing"

func TestCR(t *testing.T) {
    p := Position{Collateral: 10, Debt: 1000}
    price := 200.0
    want := (10*200)/1000.0
    if got := cr(p, price); got != want {
        t.Fatalf("cr mismatch: got %v want %v", got, want)
    }
}
