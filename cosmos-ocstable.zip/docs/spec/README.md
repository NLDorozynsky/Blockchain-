
# OC Stablecoin Module — Spec (Overview)

## Purpose
A simple **over-collateralized stablecoin** (vault) similar to Maker-style systems.
Users deposit collateral (e.g., ATOM), mint a stablecoin (e.g., USDX), and must keep a
**collateral ratio** above the **minimum**. Below the **liquidation ratio**, positions are liquidated.

## Entities
- **Position (Vault)**: tracks `collateral` and `debt` per account
- **Params**: `MCR`, `LR`, `StabilityFeeAPR`, `LiquidationPenalty`, denoms
- **Oracle**: provides collateral USD price

## Flows
- **Deposit** → increases collateral
- **Mint** → increases debt (checks post-CR ≥ MCR)
- **Withdraw** → decreases collateral (checks post-CR ≥ MCR)
- **Repay** → reduces debt
- **Accrual** → debt grows by stability fee over time
- **Liquidate** → if CR < LR, sell enough collateral to repay `debt * (1+penalty)`

This repo includes a **Go simulator** (`ocstable-sim`) that exercises these mechanics without the SDK.
