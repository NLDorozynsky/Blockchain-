
package ocstable

// NOTE: This is a scaffold for a Cosmos SDK module providing an over-collateralized
// stablecoin (vault) system. It omits full wiring, protobufs, and app integration.

import (
    sdk "github.com/cosmos/cosmos-sdk/types"
    "github.com/cosmos/cosmos-sdk/types/module"
)

var (
    ModuleName = "ocstable"
    StoreKey   = "ocstable"
    RouterKey  = "ocstable"
)

type AppModuleBasic struct{}

func (AppModuleBasic) Name() string { return ModuleName }
func (AppModuleBasic) RegisterLegacyAminoCodec(cdc *codec.LegacyAmino) {}
func (AppModuleBasic) DefaultGenesis(cdc codec.JSONCodec) json.RawMessage { return []byte("{}") }
func (AppModuleBasic) ValidateGenesis(cdc codec.JSONCodec, cfg client.TxEncodingConfig, bz json.RawMessage) error { return nil }

type AppModule struct {
    AppModuleBasic
    keeper Keeper
}

func NewAppModule(k Keeper) AppModule { return AppModule{keeper: k} }

func (am AppModule) RegisterServices(cfg module.Configurator) {}
func (am AppModule) Name() string { return ModuleName }
func (am AppModule) Route() sdk.Route { return sdk.NewRoute(RouterKey, nil) }
func (am AppModule) QuerierRoute() string { return RouterKey }
