
package types

// Parameters for OC stablecoin. In a full module, use x/params and protobufs.

type Params struct {
    DebtDenom          string  `json:"debt_denom"`
    CollateralDenom    string  `json:"collateral_denom"`
    MinCollateralRatio float64 `json:"min_collateral_ratio"`  // e.g., 1.5
    LiquidationRatio   float64 `json:"liquidation_ratio"`     // e.g., 1.2
    StabilityFeeAPR    float64 `json:"stability_fee_apr"`     // e.g., 0.05
    LiquidationPenalty float64 `json:"liquidation_penalty"`   // e.g., 0.10
}
