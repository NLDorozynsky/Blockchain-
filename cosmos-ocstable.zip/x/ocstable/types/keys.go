
package types

const (
    ModuleName = "ocstable"
    StoreKey   = ModuleName
    RouterKey  = ModuleName
)
