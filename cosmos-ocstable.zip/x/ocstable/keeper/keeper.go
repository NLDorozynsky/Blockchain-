
package keeper

// This keeper skeleton illustrates the core API expected by handlers:
// - Collateral deposit/withdraw
// - Mint/Repay stablecoin
// - Liquidate under-collateralized positions
//
// In a real app, you'd inject: bank keeper, account keeper, params, oracle interface, and store keys.

import (
    "fmt"
    sdk "github.com/cosmos/cosmos-sdk/types"
)

type Keeper struct {
    // dependencies would be injected here
    storeKey sdk.StoreKey
    cdc      codec.Codec
}

func NewKeeper(storeKey sdk.StoreKey, cdc codec.Codec /* deps */) Keeper {
    return Keeper{storeKey: storeKey, cdc: cdc}
}

// Econ params (would live in params submodule)
type Params struct {
    DebtDenom           string  // e.g., "USDX"
    CollateralDenom     string  // e.g., "ATOM"
    MinCollateralRatio  sdk.Dec // e.g., 1.5
    LiquidationRatio    sdk.Dec // e.g., 1.2
    StabilityFeeAPR     sdk.Dec // 0.05
    LiquidationPenalty  sdk.Dec // 0.10
}

func (k Keeper) CR(collateral sdk.Dec, price sdk.Dec, debt sdk.Dec) sdk.Dec {
    if debt.IsZero() {
        return sdk.NewDec(999999999) // Infinity
    }
    return collateral.Mul(price).Quo(debt)
}

func (k Keeper) MaxMintable(collateral sdk.Dec, price sdk.Dec, mcr sdk.Dec) sdk.Dec {
    // debt <= collateral * price / mcr
    return collateral.Mul(price).Quo(mcr)
}

// Simplified interest accrual (discrete step): debt *= (1 + apr * dt_years)
func (k Keeper) Accrue(debt sdk.Dec, apr sdk.Dec, dtYears sdk.Dec) sdk.Dec {
    return debt.Mul(sdk.OneDec().Add(apr.Mul(dtYears)))
}

// Liquidation math: if CR < LR, sell collateral to cover debt*(1+penalty)
func (k Keeper) LiquidationOutcome(collateral, debt, price, liqPenalty sdk.Dec) (remainingCollat sdk.Dec, repaid sdk.Dec) {
    // collateralValue = collateral*price
    // target = debt*(1+penalty)
    target := debt.Mul(sdk.OneDec().Add(liqPenalty))
    neededCollateral := target.Quo(price)
    if neededCollateral.GT(collateral) {
        // not enough collateral, everything is sold
        return sdk.ZeroDec(), collateral.Mul(price) // repaid in value terms
    }
    return collateral.Sub(neededCollateral), target.Mul(price.Quo(price)) // repaid == target (value terms)
}

func (k Keeper) String() string { return fmt.Sprintf("ocstable keeper") }
