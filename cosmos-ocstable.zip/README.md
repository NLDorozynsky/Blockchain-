
# Cosmos SDK Module — Over-collateralized Stablecoin (Go/Cosmos)

This repo contains two parts:

1. **`x/ocstable`** — a Cosmos SDK module scaffold for an **over‑collateralized stablecoin** with vaults, over‑collateralization, stability fees, and liquidations.
   * Files include `keeper`, `types`, `module.go` placeholders, genesis, msgs (scaffold).
   * Designed to be copied into an SDK app; you will need to wire it into your `app.go`, params, routing, and protobufs.

2. **`ocstable-sim`** — a **standalone Go CLI simulator** (no SDK deps) that demonstrates the economics: mint, withdraw, interest accrual,
   collateral ratio checks, and liquidation under price shocks. This is what CI builds/tests.

> The SDK module is provided as a **clean starting point** (uncompiled here to avoid heavy deps). The simulator shows the
> math and behavior you can expect in production.

## Quick start — Simulator
```bash
cd ocstable-sim
go run . -i examples/simple.json
```

## Module: Key Concepts (x/ocstable)
- **Positions (Vaults):** per account, track `collateral` and `debt`.
- **Params:**
  - `DebtDenom` (e.g., `USDX`), `CollateralDenom` (e.g., `ATOM`)
  - `MinCollateralRatio` (MCR, e.g., 150%), `LiquidationRatio` (LR, e.g., 120%)
  - `StabilityFeeAPR` (e.g., 5%), `LiquidationPenalty` (e.g., 10%)
- **Msgs:**
  - `MsgDepositCollateral`, `MsgWithdrawCollateral`
  - `MsgMint`, `MsgRepay`
  - `MsgLiquidate`
- **Oracle:** module expects a price feed (via another module or IBC). In this scaffold we treat it as an input to the keeper.

See `docs/spec/` for an architecture overview.
