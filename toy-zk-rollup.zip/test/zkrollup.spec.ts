
import { expect } from "chai";
import { ethers } from "hardhat";

describe("Toy zk-Rollup", function () {
  it("accepts proof when verifier returns true", async () => {
    const Mock = await ethers.getContractFactory("MockVerifier");
    const mock = await Mock.deploy();
    await mock.waitForDeployment();

    const Roll = await ethers.getContractFactory("Rollup");
    const roll = await Roll.deploy(await mock.getAddress());
    await roll.waitForDeployment();

    const proof = "0x";
    const signals = [1n, 2n, 3n];
    const batchHash = ethers.keccak256(ethers.toUtf8Bytes("b"));

    await expect(roll.submitBatch(proof, signals, batchHash))
      .to.emit(roll, "ProofAccepted");

    expect(await roll.accepted()).to.equal(1n);
  });

  it("reverts when verifier returns false", async () => {
    const Mock = await ethers.getContractFactory("MockVerifier");
    const mock = await Mock.deploy();
    await mock.waitForDeployment();

    // toggle mock to false
    await (await mock.setShouldVerify(false)).wait();

    const Roll = await ethers.getContractFactory("Rollup");
    const roll = await Roll.deploy(await mock.getAddress());
    await roll.waitForDeployment();

    const proof = "0x";
    const signals = [1n];
    await expect(roll.submitBatch(proof, signals, ethers.ZeroHash)).to.be.revertedWith("invalid proof");
  });
});
