
import { ethers } from "hardhat";

async function main() {
  const [deployer] = await ethers.getSigners();

  // Deploy MockVerifier (always verifies true by default)
  const Mock = await ethers.getContractFactory("MockVerifier");
  const mock = await Mock.deploy();
  await mock.waitForDeployment();

  // Deploy Rollup pointing to the mock
  const Roll = await ethers.getContractFactory("Rollup");
  const roll = await Roll.deploy(await mock.getAddress());
  await roll.waitForDeployment();

  // Dummy "proof" & pubSignals (since mock returns true)
  const proof = "0x";
  const pubSignals = [1n, 2n, 3n];
  const batchHash = ethers.keccak256(ethers.toUtf8Bytes("batch-0"));

  const tx = await roll.submitBatch(proof, pubSignals, batchHash);
  await tx.wait();

  console.log("Accepted:", (await roll.accepted()).toString());
  console.log("StateRoot:", await roll.stateRoot());
}

main().catch((e) => { console.error(e); process.exit(1); });
