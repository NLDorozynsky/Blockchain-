# NFT with On-chain Metadata & Royalties — Solidity/Foundry

An ERC-721 NFT that renders its **metadata** and **SVG image fully on-chain**.
Implements **EIP-2981 royalties** and **EIP-4906 metadata update events**.

> Educational scaffold — not audited or production-ready.

## Quick start
```bash
# Install deps
forge install openzeppelin/openzeppelin-contracts foundry-rs/forge-std

# Build & test
forge build
forge test -vv

# Deploy (local anvil)
anvil &
forge script script/Deploy.s.sol --broadcast --rpc-url http://127.0.0.1:8545
```
