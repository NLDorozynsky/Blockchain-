# Light-Client Bridge PoC — Solidity/Rust
See solidity/ and rust/bridge-sim.
