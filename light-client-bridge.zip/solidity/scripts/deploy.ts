import { ethers } from "hardhat"; import fs from "fs";
async function main(){
  const signers=await ethers.getSigners(); const validators=await Promise.all(signers.slice(0,4).map(s=>s.getAddress())); const threshold=3;
  const LC=await ethers.getContractFactory("LightClient"); const lc=await LC.deploy(validators,threshold,0,ethers.ZeroHash); await lc.waitForDeployment();
  const BR=await ethers.getContractFactory("Bridge"); const br=await BR.deploy(await lc.getAddress()); await br.waitForDeployment();
  const out={ lightClient: await lc.getAddress(), bridge: await br.getAddress(), validators, threshold }; console.log(JSON.stringify(out,null,2)); fs.writeFileSync("./deploy.json", JSON.stringify(out,null,2));
} main().catch(e=>{console.error(e);process.exit(1)});