import { keccak256, solidityPacked } from "ethers";
export function merkleize(leaves:string[]){ if(leaves.length===0) return {root:'0x'+ '00'.repeat(32), tree:[] as string[][]};
  let level=leaves.map(x=>x); const tree=[level];
  while(level.length>1){ const next:string[]=[]; for(let i=0;i<level.length;i+=2){ const a=level[i], b=i+1<level.length?level[i+1]:level[i];
    next.push(keccak256(solidityPacked(['bytes32','bytes32'],[a,b]))); } level=next; tree.push(level); }
  return { root: level[0], tree }; }
export function merkleProof(tree:string[][], idx:number){ const proof:string[]=[]; let i=idx;
  for(let lvl=0; lvl<tree.length-1; lvl++){ const nodes=tree[lvl]; const pair=i^1; const val=pair<nodes.length?nodes[pair]:nodes[i]; proof.push(val); i=Math.floor(i/2); }
  return proof; }