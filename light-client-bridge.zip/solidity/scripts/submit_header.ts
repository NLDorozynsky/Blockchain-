import { ethers } from "hardhat"; import fs from "fs"; import { merkleize } from "./_common";
async function main(){
  const dep=JSON.parse(fs.readFileSync("./deploy.json","utf-8")); const lc=await ethers.getContractAt("LightClient", dep.lightClient);
  const msgs=["hello","bridge","light","client"]; const leaves=msgs.map(m=>ethers.keccak256(ethers.solidityPacked(['string'],[m]))); const {root}=merkleize(leaves);
  const number=(await lc.latestNumber())+1n; const parent=await lc.latestHash(); const timestamp=BigInt(Math.floor(Date.now()/1000));
  const hh=ethers.keccak256(ethers.solidityPacked(["string","uint256","bytes32","bytes32","uint64"],["LC_HEADER_V1",number,parent,root,timestamp]));
  const signers=await ethers.getSigners(); const sigs:string[]=[]; const addrs:string[]=[]; for(let i=0;i<dep.validators.length && addrs.length<dep.threshold;i++){ const s=signers[i]; addrs.push(await s.getAddress()); sigs.push(await s.signMessage(ethers.getBytes(hh))); }
  await (await lc.submitHeader({number, parentHash: parent, stateRoot: root, timestamp}, sigs, addrs)).wait();
  fs.writeFileSync("./state.json", JSON.stringify({number: number.toString(), leaves}, null, 2)); console.log("submitted header", number.toString());
} main().catch(e=>{console.error(e);process.exit(1)});