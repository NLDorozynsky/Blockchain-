import { ethers } from "hardhat"; import fs from "fs"; import { merkleize, merkleProof } from "./_common";
async function main(){
  const dep=JSON.parse(fs.readFileSync("./deploy.json","utf-8")); const st=JSON.parse(fs.readFileSync("./state.json","utf-8"));
  const br=await ethers.getContractAt("Bridge", dep.bridge); const number=BigInt(st.number); const leaves:string[]=st.leaves;
  const {tree}=merkleize(leaves); const idx=0; const proof=merkleProof(tree, idx); const ok=await br.verifyMessage(number, leaves[idx], proof); console.log("proof ok?", ok);
} main().catch(e=>{console.error(e);process.exit(1)});