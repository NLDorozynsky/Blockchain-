import { expect } from "chai"; import { ethers } from "hardhat"; import { merkleize, merkleProof } from "../scripts/_common";
describe("LC Bridge", function(){
  it("header + merkle verify", async()=>{
    const signers=await ethers.getSigners(); const validators=await Promise.all(signers.slice(0,4).map(s=>s.getAddress())); const threshold=3;
    const LC=await ethers.getContractFactory("LightClient"); const lc=await LC.deploy(validators,threshold,0,ethers.ZeroHash); await lc.waitForDeployment();
    const BR=await ethers.getContractFactory("Bridge"); const br=await BR.deploy(await lc.getAddress()); await br.waitForDeployment();
    const leaves=["a","b","c","d"].map(m=>ethers.keccak256(ethers.solidityPacked(['string'],[m]))); const {root, tree}=merkleize(leaves);
    const number=(await lc.latestNumber())+1n; const parent=await lc.latestHash(); const ts=BigInt(Math.floor(Date.now()/1000));
    const hh=ethers.keccak256(ethers.solidityPacked(["string","uint256","bytes32","bytes32","uint64"],["LC_HEADER_V1",number,parent,root,ts]));
    const sigs:string[]=[]; const addrs:string[]=[]; for(let i=0;i<threshold;i++){ const s=signers[i]; addrs.push(await s.getAddress()); sigs.push(await s.signMessage(ethers.getBytes(hh))); }
    await (await lc.submitHeader({number, parentHash: parent, stateRoot: root, timestamp: ts}, sigs, addrs)).wait();
    const proof=merkleProof(tree, 2); expect(await br.verifyMessage(number, leaves[2], proof)).eq(true);
  });
});