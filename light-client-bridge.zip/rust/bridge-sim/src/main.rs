
use anyhow::Result;
use clap::{Parser, Subcommand};
use k256::ecdsa::{SigningKey, Signature, signature::Signer};
use k256::ecdsa::recoverable::{Signature as RecoverableSig};
use k256::ecdsa::VerifyingKey;
use sha3::{Digest, Keccak256};
use rand::rngs::OsRng;
use serde::{Serialize, Deserialize};

#[derive(Parser, Debug)]
#[command(name="bridge-sim")]
struct Cli { #[command(subcommand)] cmd: Cmd }

#[derive(Subcommand, Debug)]
enum Cmd {
    Keys { #[arg(long, default_value_t=4)] n: usize },
    Header { #[arg(long)] parent: String, #[arg(long)] number: u64, #[arg(long)] timestamp: u64, #[arg(long)] threshold: usize, #[arg(long)] leaves: String },
}

#[derive(Serialize, Deserialize)]
struct Key { priv_hex: String, address: String }

fn eth_addr_from_vk(vk: &VerifyingKey) -> String {
    let uncompressed = vk.to_encoded_point(false);
    let pub_bytes = &uncompressed.as_bytes()[1..];
    let mut hasher = Keccak256::new();
    hasher.update(pub_bytes);
    let hash = hasher.finalize();
    format!("0x{}", hex::encode(&hash[12..]))
}

#[derive(Serialize)]
struct HeaderOut { number: u64, parent: String, root: String, timestamp: u64, header_hash: String, signatures: Vec<String>, signers: Vec<String> }

fn keccak(data: &[u8]) -> [u8; 32] { let mut h = Keccak256::new(); h.update(data); let out = h.finalize(); let mut arr = [0u8; 32]; arr.copy_from_slice(&out); arr }

fn merkle_root(mut leaves: Vec<[u8; 32]>) -> [u8; 32] {
    if leaves.is_empty() { return [0u8; 32]; }
    while leaves.len() > 1 {
        let mut next: Vec<[u8; 32]> = Vec::with_capacity((leaves.len()+1)/2);
        for i in (0..leaves.len()).step_by(2) {
            let a = leaves[i]; let b = if i+1<leaves.len() { leaves[i+1] } else { leaves[i] };
            let mut v = Vec::with_capacity(64); v.extend_from_slice(&a); v.extend_from_slice(&b); next.push(keccak(&v));
        }
        leaves = next;
    }
    leaves[0]
}

fn main() -> Result<()> {
    let cli = Cli::parse();
    match cli.cmd {
        Cmd::Keys { n } => {
            let mut out: Vec<Key> = Vec::new();
            for _ in 0..n {
                let sk = SigningKey::random(&mut OsRng);
                let vk = sk.verifying_key();
                out.push(Key { priv_hex: format!("0x{}", hex::encode(sk.to_bytes())), address: eth_addr_from_vk(&vk) });
            }
            println!("{}", serde_json::to_string_pretty(&out)?);
        }
        Cmd::Header { parent, number, timestamp, threshold, leaves } => {
            let lvec: Vec<String> = serde_json::from_str(&leaves)?;
            let mut lv: Vec<[u8; 32]> = Vec::new();
            for h in lvec {
                let s = h.trim_start_matches("0x");
                let b = hex::decode(s)?;
                let mut arr = [0u8; 32]; arr.copy_from_slice(&b); lv.push(arr);
            }
            let root = merkle_root(lv);
            let mut data = Vec::new();
            data.extend_from_slice(b"LC_HEADER_V1");
            data.extend_from_slice(&number.to_be_bytes());
            let parent_bytes = hex::decode(parent.trim_start_matches("0x"))?; data.extend_from_slice(&parent_bytes);
            data.extend_from_slice(&root);
            data.extend_from_slice(&timestamp.to_be_bytes());
            let hh = keccak(&data);
            let mut sigs: Vec<String> = Vec::new();
            let mut addrs: Vec<String> = Vec::new();
            for _ in 0..threshold {
                let sk = SigningKey::random(&mut OsRng);
                let vk = sk.verifying_key();
                let rsig: RecoverableSig = sk.sign(&hh);
                let sig: Signature = rsig.clone().into();
                let recid: u8 = rsig.recovery_id().into();
                let mut full = Vec::new(); full.extend_from_slice(&sig.to_bytes());
                let v = 27u8 + recid; full.push(v);
                sigs.push(format!("0x{}", hex::encode(full)));
                addrs.push(eth_addr_from_vk(&vk));
            }
            let out = HeaderOut { number, parent, root: format!("0x{}", hex::encode(root)), timestamp, header_hash: format!("0x{}", hex::encode(hh)), signatures: sigs, signers: addrs };
            println!("{}", serde_json::to_string_pretty(&out)?);
        }
    }
    Ok(())
}
