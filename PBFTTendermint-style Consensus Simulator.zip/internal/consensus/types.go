package consensus
type Mode string; const( ModePBFT Mode="pbft"; ModeTendermint Mode="tendermint" )
type MsgType string; const( MsgPrePrepare MsgType="preprepare"; MsgPrepare MsgType="prepare"; MsgCommit MsgType="commit"; MsgProposal MsgType="proposal"; MsgPrevote MsgType="prevote"; MsgPrecommit MsgType="precommit" )
type Message struct{ From,To,Height,Round int; Type MsgType; BlockID string }
type Event struct{ Tick int `json:"tick"`; Type string `json:"type"`; Node,From,To,Height,Round int `json:"node","from","to","height","round"`; BlockID,Detail string `json:"blockId","detail"` }
type EventSink interface{ Emit(Event) }
type NopSink struct{}; func (NopSink) Emit(Event) {}
type ChannelSink struct{ Out chan<- Event }; func (c ChannelSink) Emit(e Event){ select{ case c.Out<-e: default: } }
