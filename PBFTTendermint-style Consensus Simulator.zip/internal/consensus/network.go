package consensus
import "math/rand"
type env struct{ Msg Message; DeliverAt int }
type Network struct{ N,MinLatency,MaxLatency int; DropProb float64; rng *rand.Rand; q []env; sink EventSink; now int }
func NewNetwork(n,min,max int,drop float64,r *rand.Rand,s EventSink)*Network{ return &Network{N:n,MinLatency:min,MaxLatency:max,DropProb:drop,rng:r,q:make([]env,0),sink:s} }
func (net *Network)latency()int{ if net.MaxLatency<=net.MinLatency{return net.MinLatency}; d:=net.MaxLatency-net.MinLatency+1; return net.MinLatency+net.rng.Intn(d) }
func (net *Network)TickNow(t int){ net.now=t }
func (net *Network)Enqueue(t int,m Message){ if net.DropProb>0 && net.rng.Float64()<net.DropProb{ if net.sink!=nil{ net.sink.Emit(Event{Tick:t,Type:"drop",From:m.From,To:m.To,Height:m.Height,Round:m.Round,BlockID:m.BlockID,Detail:string(m.Type)})}; return}; if net.sink!=nil{ net.sink.Emit(Event{Tick:t,Type:"send",From:m.From,To:m.To,Height:m.Height,Round:m.Round,BlockID:m.BlockID,Detail:string(m.Type)})}; net.q=append(net.q,env{m,t+net.latency()}) }
func (net *Network)BroadcastExceptSelf(t,from int,m Message){ for to:=0; to<net.N; to++{ if to==from{continue}; mm:=m; mm.To=to; net.Enqueue(t,mm) } }
func (net *Network)PopDue(t int)[]Message{ due:=make([]Message,0); kept:=make([]env,0,len(net.q)); for _,e:=range net.q{ if e.DeliverAt<=t{ due=append(due,e.Msg); if net.sink!=nil{ net.sink.Emit(Event{Tick:t,Type:"deliver",From:e.Msg.From,To:e.Msg.To,Height:e.Msg.Height,Round:e.Msg.Round,BlockID:e.Msg.BlockID,Detail:string(e.Msg.Type)})}} else { kept=append(kept,e) } }; net.q=kept; return due }
