package consensus
import "testing"
func TestPBFT_Safety_WithEquivocatingProposer(t *testing.T){ sim:=NewSimulator(4,1,ModePBFT,1,1,3,0.0,7,true); sim.Run(); ok,why:=sim.SafetyOK(); if !ok{ t.Fatalf("safety violated: %s",why) } }
func TestTendermint_Liveness_NoFaults(t *testing.T){ sim:=NewSimulator(4,1,ModeTendermint,2,1,3,0.0,9,false); sim.Run(); for _,n:=range sim.Nodes{ if _,ok:=n.Committed[2]; !ok{ t.Fatalf("node %d missing commit",n.ID) } }; if ok,_:=sim.SafetyOK(); !ok{ t.Fatalf("safety should hold") } }
