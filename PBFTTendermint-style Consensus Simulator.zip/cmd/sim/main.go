package main
import("context";"embed";"encoding/json";"flag";"fmt";"log";"net/http";"os";"time";"pbftsim/internal/consensus")
//go:embed web/*
var webFS embed.FS
type SSEHub struct{ clients map[chan consensus.Event]struct{}; add,remove chan chan consensus.Event; broadcast chan consensus.Event }
func NewHub()*SSEHub{ return &SSEHub{clients:map[chan consensus.Event]struct{}{},add:make(chan chan consensus.Event),remove:make(chan chan consensus.Event),broadcast:make(chan consensus.Event,1024)} }
func (h *SSEHub)Run(ctx context.Context){ for{ select{ case <-ctx.Done():return; case c:=<-h.add:h.clients[c]=struct{}{}; case c:=<-h.remove: delete(h.clients,c); close(c); case ev:=<-h.broadcast: for c:=range h.clients{ select{ case c<-ev: default: } } } } }
func (h *SSEHub)Events(w http.ResponseWriter,r *http.Request){ w.Header().Set("Content-Type","text/event-stream"); w.Header().Set("Cache-Control","no-cache"); w.Header().Set("Connection","keep-alive"); f,ok:=w.(http.Flusher); if !ok{ http.Error(w,"no flush",500); return }; ch:=make(chan consensus.Event,64); h.add<-ch; defer func(){h.remove<-ch}(); fmt.Fprintf(w,":ok\n\n"); f.Flush(); for{ select{ case <-r.Context().Done(): return; case ev:=<-ch: b,_:=json.Marshal(ev); fmt.Fprintf(w,"data: %s\n\n",string(b)); f.Flush() } } }
func main(){ var n,f,heights,min,max int; var modeStr string; var drop float64; var seed int64; var equiv,viz bool
 flag.IntVar(&n,"n",4,"validators"); flag.IntVar(&f,"f",1,"faults"); flag.IntVar(&heights,"heights",1,"heights"); flag.StringVar(&modeStr,"mode","pbft","pbft|tendermint"); flag.IntVar(&min,"min_latency",1,"min"); flag.IntVar(&max,"max_latency",5,"max"); flag.Float64Var(&drop,"drop",0,"drop"); flag.Int64Var(&seed,"seed",42,"seed"); flag.BoolVar(&equiv,"equivocate_proposer",false,"equiv"); flag.BoolVar(&viz,"viz",false,"viz"); flag.Parse()
 var mode consensus.Mode; switch modeStr{ case "pbft":mode=consensus.ModePBFT; case "tendermint":mode=consensus.ModeTendermint; default: fmt.Println("unknown mode:",modeStr); os.Exit(2) }
 if !viz{ sim:=consensus.NewSimulator(n,f,mode,heights,min,max,drop,seed,equiv); sim.Run(); ok,why:=sim.SafetyOK(); fmt.Printf("Finished at tick %d\nSafety OK: %v\n",sim.Tick,ok); if !ok{ fmt.Println("Reason:",why) }; for _,node:=range sim.Nodes{ fmt.Printf("Node %d: ",node.ID); for h:=1; h<=heights; h++{ if b,ok:=node.Committed[h]; ok{ fmt.Printf("[h=%d %s] ",h,b) } else { fmt.Printf("[h=%d none] ",h) } }; fmt.Println() }; if !ok{ os.Exit(1) }; return }
 ctx,cancel:=context.WithCancel(context.Background()); defer cancel(); hub:=NewHub(); go hub.Run(ctx)
 evch:=make(chan consensus.Event,1024); sink:=consensus.ChannelSink{Out:evch}; go func(){ for ev:=range evch{ hub.broadcast<-ev } }()
 http.HandleFunc("/events",hub.Events); fs:=http.FS(webFS); http.Handle("/web/",http.FileServer(fs)); http.HandleFunc("/",func(w http.ResponseWriter,r *http.Request){ b,_:=webFS.ReadFile("web/index.html"); w.Header().Set("Content-Type","text/html; charset=utf-8"); w.Write(b) })
 go func(){ time.Sleep(300*time.Millisecond); sim:=consensus.NewSimulatorWithSink(n,f,mode,heights,min,max,drop,seed,equiv,sink); sim.Run(); ok,why:=sim.SafetyOK(); log.Printf("Finished at tick %d safety=%v reason=%s",sim.Tick,ok,why) }()
 log.Println("Visualizer on http://localhost:8080/"); log.Fatal(http.ListenAndServe(":8080",nil)) }
