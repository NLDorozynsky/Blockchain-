# PBFT/Tendermint Simulator with Web Visualizer
Run: `go run ./cmd/sim --viz` and open http://localhost:8080/
