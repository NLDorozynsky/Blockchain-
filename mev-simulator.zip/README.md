# MEV Simulator (auctions & reordering) — Python/Jupyter

A didactic simulator for **MEV** dynamics with a simple mempool model, block auctions,
and reordering policies. Includes Jupyter notebooks to explore:

- FIFO vs. greedy vs. knapsack-like block building
- Miner revenue vs. user cost tradeoffs
- A toy **sandwich** model on a constant-product AMM

> Educational only. This code is simplified — not for production use.

## Quick start
```bash
# Create a venv (optional) and install deps
python -m venv .venv && . .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Open the notebooks
jupyter lab  # or: jupyter notebook
#  - notebooks/01_basics.ipynb
#  - notebooks/02_sandwich.ipynb
```

## Contents
- `mevsim/mempool.py` — transaction generation
- `mevsim/auctions.py` — gas auctions, block building
- `mevsim/reorder.py` — policies: FIFO, greedy (value/gas), knapsack-ish
- `mevsim/amm.py` — tiny constant-product AMM for swap/sandwich demos
- `mevsim/metrics.py` — miner revenue, user cost
- `notebooks/01_basics.ipynb` — block building comparison
- `notebooks/02_sandwich.ipynb` — sandwich profitability & slippage
- `demo_cli.py` — headless demonstration
- `requirements.txt` — numpy, pandas, matplotlib, scipy (optional), jupyter

© 2025
