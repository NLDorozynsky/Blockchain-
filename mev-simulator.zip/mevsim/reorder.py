from __future__ import annotations
from typing import List, Tuple
from .mempool import Tx

def knapsack_like(mempool: List[Tx], gas_limit: int = 1_500_000, scale: int = 1000) -> Tuple[List[Tx], float]:
    # Coarse-grained DP knapsack: gas compressed by 'scale' to keep DP table small
    # Value ~ miner revenue proxy
    items = list(mempool)
    weights = [max(1, t.gas // scale) for t in items]
    values = [t.bid * t.gas + max(0.0, t.value) for t in items]
    W = max(1, gas_limit // scale)
    n = len(items)
    # DP table
    dp = [[0.0]*(W+1) for _ in range(n+1)]
    take = [[False]*(W+1) for _ in range(n+1)]
    for i in range(1, n+1):
        w = weights[i-1]; v = values[i-1]
        for cap in range(W+1):
            dp[i][cap] = dp[i-1][cap]
            if w <= cap and dp[i-1][cap-w] + v > dp[i][cap]:
                dp[i][cap] = dp[i-1][cap-w] + v
                take[i][cap] = True
    # Backtrack
    res: List[Tx] = []
    cap = W
    for i in range(n, 0, -1):
        if take[i][cap]:
            res.append(items[i-1]); cap -= weights[i-1]
    res.reverse()
    gas_used = sum(t.gas for t in res)
    value = sum(t.bid * t.gas + max(0.0, t.value) for t in res)
    # Filter if gas overflow due to rounding
    sel: List[Tx] = []
    g = 0
    for t in res:
        if g + t.gas <= gas_limit:
            sel.append(t); g += t.gas
    value = sum(t.bid * t.gas + max(0.0, t.value) for t in sel)
    return sel, value
