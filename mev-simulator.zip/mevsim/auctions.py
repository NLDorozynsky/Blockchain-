from __future__ import annotations
from typing import List, Tuple
from .mempool import Tx

def block_value(txs: List[Tx]) -> float:
    # Miner revenue proxy: sum(tip_per_gas * gas) + sum(extractable value >= 0)
    tips = sum(t.bid * t.gas for t in txs)
    ev = sum(max(0.0, t.value) for t in txs)
    return tips + ev

def build_block_fifo(mempool: List[Tx], gas_limit: int = 15_000_000) -> Tuple[List[Tx], float]:
    selected: List[Tx] = []
    gas = 0
    for t in mempool:
        if gas + t.gas > gas_limit: break
        selected.append(t); gas += t.gas
    return selected, block_value(selected)

def build_block_greedy(mempool: List[Tx], gas_limit: int = 15_000_000, key="value_per_gas") -> Tuple[List[Tx], float]:
    def vpg(t: Tx) -> float:
        return (t.bid * t.gas + max(0.0, t.value)) / max(1, t.gas)
    # Sort by descending value-per-gas (ties broken by bid)
    order = sorted(mempool, key=lambda t: (vpg(t), t.bid), reverse=True)
    selected: List[Tx] = []
    gas = 0
    for t in order:
        if gas + t.gas <= gas_limit:
            selected.append(t); gas += t.gas
    return selected, block_value(selected)
