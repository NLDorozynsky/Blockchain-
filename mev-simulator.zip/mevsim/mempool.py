from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional
import random

@dataclass
class Tx:
    txid: str
    gas: int
    bid: float  # tip in native per gas (e.g., gwei-equivalent units)
    value: float  # economic value captured if fully executed (can be 0 for pure transfers)
    kind: str = "normal"  # normal|arb|liquidation|swap
    meta: Optional[dict] = None

def generate_mempool(n: int = 200, seed: int = 1, gas_range=(21_000, 120_000)) -> List[Tx]:
    rnd = random.Random(seed)
    txs: List[Tx] = []
    kinds = (["normal"] * 70) + (["arb"] * 15) + (["liquidation"] * 10) + (["swap"] * 5)
    for i in range(n):
        k = rnd.choice(kinds)
        gas = rnd.randint(gas_range[0], gas_range[1])
        if k == "normal":
            bid = rnd.uniform(1, 30)
            value = 0.0
        elif k == "arb":
            bid = rnd.uniform(10, 80)
            value = rnd.uniform(0.01, 0.5)
        elif k == "liquidation":
            bid = rnd.uniform(20, 120)
            value = rnd.uniform(0.05, 1.0)
        else:  # swap
            bid = rnd.uniform(5, 50)
            value = rnd.uniform(-0.2, 0.2)  # slippage may be negative to users
        txs.append(Tx(f"tx{i:05d}", gas, bid, value, k))
    return txs
