from __future__ import annotations
from typing import List
from .mempool import Tx

def miner_revenue(txs: List[Tx]) -> float:
    return sum(t.bid * t.gas for t in txs) + sum(max(0.0, t.value) for t in txs)

def user_surplus_change(txs: List[Tx]) -> float:
    # Negative if users lose value due to reordering; here simply -sum(negative tx.value)
    return -sum(min(0.0, t.value) for t in txs)
