from __future__ import annotations
from dataclasses import dataclass

@dataclass
class Pool:
    x: float  # reserve token X (e.g., ETH)
    y: float  # reserve token Y (e.g., ERC20)
    k: float  # x*y (constant product), updated with fees

def swap_x_for_y(p: Pool, dx: float, fee_bps: int = 30) -> tuple[Pool, float]:
    # fee deducted from input amount
    dx_eff = dx * (1 - fee_bps/10_000)
    new_x = p.x + dx_eff
    new_y = p.k / new_x
    dy = p.y - new_y
    return Pool(new_x, new_y, p.k), dy

def price_impact(p: Pool, dx: float, fee_bps: int = 30) -> float:
    _, dy = swap_x_for_y(p, dx, fee_bps)
    return dy / p.y
