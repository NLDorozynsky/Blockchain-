#!/usr/bin/env python3
import argparse
from mevsim.mempool import generate_mempool
from mevsim.auctions import build_block_fifo, build_block_greedy
from mevsim.reorder import knapsack_like
from mevsim.metrics import miner_revenue, user_surplus_change

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--n', type=int, default=200)
    ap.add_argument('--gas-limit', type=int, default=3_000_000)
    args = ap.parse_args()

    mem = generate_mempool(n=args.n, seed=42, gas_range=(21_000, 120_000))
    fifo, v_fifo = build_block_fifo(mem, args.gas_limit)
    greedy, v_greedy = build_block_greedy(mem, args.gas_limit)
    knap, v_knap = knapsack_like(mem, args.gas_limit, scale=10_000)

    print('FIFO   : txs', len(fifo), 'revenue', v_fifo)
    print('Greedy : txs', len(greedy), 'revenue', v_greedy)
    print('Knapsack-like: txs', len(knap), 'revenue', v_knap)
    print('User surplus loss (neg values counted):', user_surplus_change(knap))

if __name__ == '__main__':
    main()
