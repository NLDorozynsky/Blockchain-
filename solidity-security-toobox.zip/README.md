# Solidity Security Toolbox (fuzz/invariants templates) — Foundry

A hands-on **security testing toolbox** for Solidity using Foundry. Includes:

- **Fuzz testing** templates (stateful & property-based)
- **Invariant testing** harness (StdInvariant + Handler pattern)
- A deliberately vulnerable **Bank** contract (reentrancy) and a safe variant
- Reentrancy **attacker** contract to demonstrate exploitation

> Educational scaffold — not audited or production-ready.

## Quick start
```bash
forge install foundry-rs/forge-std
forge build
forge test -vv
```

## What’s inside
- `src/Bank.sol` — vulnerable bank (reentrancy via CEI violation)
- `src/BankSafe.sol` — fixed bank with nonReentrant + CEI
- `src/Attacker.sol` — reentrancy PoC
- `test/FuzzExamples.t.sol` — boundary/assumption‑based fuzz tests
- `test/Invariant_Bank.t.sol` — StdInvariant + Handler pattern (stateful fuzzer)

### Tips
- Set **bounds** on fuzz inputs with `vm.assume()` or `bound()` to keep tests meaningful
- Use **targetSelectors** and **targetContract** to direct invariant fuzzers
- Prefer **CEI** + **reentrancy guards** + checks for external calls returning false
