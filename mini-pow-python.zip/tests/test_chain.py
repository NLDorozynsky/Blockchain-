
import os, shutil
from minipow.chain import Blockchain
from minipow.wallet import keygen

def setup_module(module):
    d = "./data"
    if os.path.exists(d):
        shutil.rmtree(d)

def test_mine_basic(tmp_path):
    bc = Blockchain(datadir=str(tmp_path / "data"))
    priv, pub_hex, addr = keygen()
    blk, _ = bc.mine_block(addr, max_nonce=200000)
    assert blk is not None
    assert bc.address_balance(addr) >= bc.current_subsidy()
    assert bc.is_valid_chain()
