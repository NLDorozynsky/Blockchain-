
from dataclasses import dataclass, asdict
from typing import List, Tuple, Dict, Optional
import json
from .crypto import double_sha256
from .keys import verify

@dataclass
class TxIn:
    prev_txid: str
    prev_index: int
    pubkey_hex: str
    signature_hex: str

@dataclass
class TxOut:
    amount: int
    address: str  # base58check

@dataclass
class Transaction:
    vin: List[TxIn]
    vout: List[TxOut]
    coinbase: bool = False

    def serialize(self, include_sigs: bool=True) -> bytes:
        # canonical JSON
        tx = {
            "vin": [
                {
                    "prev_txid": i.prev_txid,
                    "prev_index": i.prev_index,
                    "pubkey_hex": i.pubkey_hex if include_sigs else "",
                    "signature_hex": i.signature_hex if include_sigs else ""
                } for i in self.vin
            ],
            "vout": [asdict(o) for o in self.vout],
            "coinbase": self.coinbase,
        }
        return json.dumps(tx, sort_keys=True, separators=(",", ":")).encode()

    def txid(self) -> str:
        return double_sha256(self.serialize()).hex()

    def preimage(self) -> bytes:
        # hash w/o signatures
        return self.serialize(include_sigs=False)

def validate_tx(tx: Transaction, utxo: Dict[Tuple[str, int], TxOut]) -> Optional[str]:
    # coinbase: only one output, no inputs, amount checked by miner/chain
    if tx.coinbase:
        if tx.vin:
            return "coinbase must have 0 inputs"
        if len(tx.vout) != 1:
            return "coinbase must have exactly 1 output"
        if tx.vout[0].amount <= 0:
            return "coinbase output must be positive"
        return None

    if not tx.vin or not tx.vout:
        return "tx must have inputs and outputs"

    total_in = 0
    seen = set()
    for i, tin in enumerate(tx.vin):
        key = (tin.prev_txid, tin.prev_index)
        if key in seen:
            return "duplicate input reference"
        seen.add(key)
        prev_out = utxo.get(key)
        if prev_out is None:
            return f"referenced output not found: {key}"
        total_in += prev_out.amount

        # signature
        try:
            ok = verify(bytes.fromhex(tin.pubkey_hex), bytes.fromhex(tin.signature_hex), tx.preimage())
        except Exception:
            return "invalid signature encoding"
        if not ok:
            return "signature verification failed"

    total_out = sum(o.amount for o in tx.vout)
    if total_out <= 0:
        return "outputs must be positive"

    if total_out > total_in:
        return f"insufficient input value: in={total_in}, out={total_out}"

    return None
