
from .keys import generate_keypair
from .crypto import address_from_pubkey

def keygen():
    sk, vk = generate_keypair()
    priv_hex = sk.to_string().hex()
    pub_bytes = vk.to_string()
    addr = address_from_pubkey(pub_bytes)
    return priv_hex, pub_bytes.hex(), addr
