
from dataclasses import dataclass, asdict
from typing import List
import json, time
from .crypto import double_sha256, merkle_root
from .tx import Transaction

@dataclass
class BlockHeader:
    prev_hash: str
    merkle_root: str
    timestamp: int
    target: int  # target as int (max hash value allowed)
    nonce: int = 0

    def serialize(self) -> bytes:
        obj = asdict(self)
        return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()

    def hash(self) -> str:
        return double_sha256(self.serialize()).hex()

@dataclass
class Block:
    header: BlockHeader
    txs: List[Transaction]

    @staticmethod
    def build(prev_hash: str, txs: List[Transaction], target: int) -> "Block":
        leaves = [bytes.fromhex(tx.txid()) for tx in txs]
        root = merkle_root(leaves).hex()
        hdr = BlockHeader(prev_hash=prev_hash, merkle_root=root, timestamp=int(time.time()), target=target, nonce=0)
        return Block(hdr, txs)

    def hash(self) -> str:
        return self.header.hash()

    def meets_target(self) -> bool:
        return int(self.hash(), 16) <= self.header.target
