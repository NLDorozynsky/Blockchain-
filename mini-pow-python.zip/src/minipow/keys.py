
from ecdsa import SigningKey, SECP256k1, VerifyingKey, BadSignatureError

def generate_keypair():
    sk = SigningKey.generate(curve=SECP256k1)
    vk = sk.get_verifying_key()
    return sk, vk

def priv_to_pub(priv_hex: str):
    sk = SigningKey.from_string(bytes.fromhex(priv_hex), curve=SECP256k1)
    vk = sk.get_verifying_key()
    return vk

def sign(priv_hex: str, message: bytes) -> bytes:
    sk = SigningKey.from_string(bytes.fromhex(priv_hex), curve=SECP256k1)
    return sk.sign_deterministic(message)

def verify(pubkey_bytes: bytes, signature: bytes, message: bytes) -> bool:
    try:
        vk = VerifyingKey.from_string(pubkey_bytes, curve=SECP256k1)
        vk.verify(signature, message)
        return True
    except BadSignatureError:
        return False
