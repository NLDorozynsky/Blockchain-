
import argparse, sys, json
from .wallet import keygen
from .chain import Blockchain
from .tx import Transaction, TxIn, TxOut
from .keys import sign, priv_to_pub

def cmd_keygen(args):
    priv, pub_hex, addr = keygen()
    print(f"priv_hex: {priv}")
    print(f"pub_hex: {pub_hex}")
    print(f"address: {addr}")

def cmd_status(args):
    chain = Blockchain()
    print(json.dumps({
        "height": len(chain.blocks)-1,
        "tip": chain.blocks[-1].hash(),
        "mempool": len(chain.mempool),
        "current_target": chain.current_target(),
        "current_subsidy": chain.current_subsidy(),
        "valid": chain.is_valid_chain(),
    }, indent=2))

def cmd_balance(args):
    chain = Blockchain()
    bal = chain.address_balance(args.address)
    print(bal)

def cmd_send(args):
    chain = Blockchain()
    # Build a simple spend: gather UTXOs for from-address derived from pubkey
    vk = priv_to_pub(args.from_priv)
    from_addr = None  # we don't store address directly; derive from pubkey when validating
    # For a safer demo, allow a hint address to filter UTXOs:
    if args.hint_address:
        from_addr = args.hint_address

    selected = []
    total = 0
    for (txid, idx), out in list(chain.utxo.items()):
        if from_addr and out.address != from_addr:
            continue
        selected.append(((txid, idx), out))
        total += out.amount
        if total >= args.amount:
            break
    if total < args.amount:
        print("Insufficient funds in demo wallet. Provide --hint-address to filter.", file=sys.stderr)
        sys.exit(1)

    change = total - args.amount
    vin = []
    # construct unsigned tx preimage first
    tmp_tx = Transaction(vin=[], vout=[TxOut(amount=args.amount, address=args.to)] + ([TxOut(amount=change, address=from_addr)] if change>0 and from_addr else []), coinbase=False)
    pre = tmp_tx.preimage()

    for (txid, idx), out in selected:
        sig = sign(args.from_priv, pre).hex()
        vin.append(TxIn(prev_txid=txid, prev_index=idx, pubkey_hex=vk.to_string().hex(), signature_hex=sig))

    tx = Transaction(vin=vin, vout=tmp_tx.vout, coinbase=False)
    err = chain.add_mempool_tx(tx)
    if err:
        print("TX rejected:", err, file=sys.stderr)
        sys.exit(1)
    print(tx.txid())

def cmd_mine(args):
    chain = Blockchain()
    blk, iters = chain.mine_block(args.miner_address, max_nonce=args.max_nonce)
    if blk is None:
        print("Mining gave up after", iters, "iterations without a hit.", file=sys.stderr)
        sys.exit(2)
    print(json.dumps({
        "height": len(chain.blocks)-1,
        "hash": blk.hash(),
        "nonce": blk.header.nonce,
        "txs": len(blk.txs),
        "subsidy": chain.current_subsidy(),
    }, indent=2))

def build_parser():
    p = argparse.ArgumentParser(prog="minipow", description="Mini PoW blockchain")
    sub = p.add_subparsers(required=True)

    sp = sub.add_parser("keygen", help="generate a private/public keypair and address")
    sp.set_defaults(func=cmd_keygen)

    sp = sub.add_parser("status", help="show chain status")
    sp.set_defaults(func=cmd_status)

    sp = sub.add_parser("balance", help="show address balance")
    sp.add_argument("--address", required=True)
    sp.set_defaults(func=cmd_balance)

    sp = sub.add_parser("send", help="create and submit a signed tx to mempool")
    sp.add_argument("--from-priv", required=True)
    sp.add_argument("--to", required=True)
    sp.add_argument("--amount", required=True, type=int)
    sp.add_argument("--hint-address", help="address to treat as change address & filter UTXOs")
    sp.set_defaults(func=cmd_send)

    sp = sub.add_parser("mine", help="mine a block paying coinbase to an address")
    sp.add_argument("--miner-address", required=True)
    sp.add_argument("--max-nonce", type=int, default=2_000_000)
    sp.set_defaults(func=cmd_mine)

    return p

def main(argv=None):
    argv = argv or sys.argv[1:]
    p = build_parser()
    args = p.parse_args(argv)
    args.func(args)

if __name__ == "__main__":
    main()
