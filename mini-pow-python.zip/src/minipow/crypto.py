
import hashlib
from typing import List

ALPHABET = b'123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz'

def sha256(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()

def double_sha256(b: bytes) -> bytes:
    return sha256(sha256(b))

def ripemd160(b: bytes) -> bytes:
    h = hashlib.new('ripemd160')
    h.update(b)
    return h.digest()

def merkle_root(leaves: List[bytes]) -> bytes:
    if not leaves:
        return b"\x00"*32
    level = [hashlib.sha256(x).digest() for x in leaves]
    while len(level) > 1:
        if len(level) % 2 == 1:
            level.append(level[-1])
        level = [hashlib.sha256(level[i] + level[i+1]).digest() for i in range(0, len(level), 2)]
    return level[0]

def b58encode(b: bytes) -> str:
    # simple base58 without checksum
    n = int.from_bytes(b, 'big')
    res = bytearray()
    while n > 0:
        n, r = divmod(n, 58)
        res.append(ALPHABET[r])
    # leading zeros
    pad = 0
    for byte in b:
        if byte == 0:
            pad += 1
        else:
            break
    return (ALPHABET[0:1]*pad + res[::-1]).decode()

def b58check_encode(payload: bytes) -> str:
    checksum = double_sha256(payload)[:4]
    return b58encode(payload + checksum)

def address_from_pubkey(pubkey_bytes: bytes) -> str:
    h160 = ripemd160(sha256(pubkey_bytes))
    versioned = b"\x00" + h160  # version 0
    return b58check_encode(versioned)
