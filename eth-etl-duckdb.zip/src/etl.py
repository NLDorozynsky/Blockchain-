from __future__ import annotations
import os, sys, argparse, time
from typing import Any, Dict, List
from dotenv import load_dotenv
from web3 import Web3
import pandas as pd
from tqdm import tqdm
from pathlib import Path

load_dotenv()

def hex_to_int(x):
    if x is None: return None
    if isinstance(x, int): return x
    if isinstance(x, str) and x.startswith('0x'):
        return int(x, 16)
    return x

def normalize_block(b: Dict[str, Any]) -> Dict[str, Any]:
    return {
        'number': int(b['number']),
        'hash': b['hash'].hex() if hasattr(b['hash'], 'hex') else b['hash'],
        'parent_hash': b['parentHash'].hex() if hasattr(b['parentHash'], 'hex') else b['parentHash'],
        'timestamp': int(b['timestamp']),
        'miner': b.get('miner'),
        'gas_limit': int(b.get('gasLimit', 0)),
        'gas_used': int(b.get('gasUsed', 0)),
        'base_fee_per_gas': hex_to_int(b.get('baseFeePerGas')) if b.get('baseFeePerGas') is not None else None,
        'size': hex_to_int(b.get('size')) if b.get('size') is not None else None,
        'tx_count': len(b.get('transactions', [])),
    }

def normalize_tx(t: Dict[str, Any], block_number: int) -> Dict[str, Any]:
    return {
        'hash': t['hash'].hex() if hasattr(t['hash'], 'hex') else t['hash'],
        'block_number': block_number,
        'from': t.get('from'),
        'to': t.get('to'),
        'value': int(t.get('value', 0)),
        'nonce': int(t.get('nonce', 0)),
        'gas': int(t.get('gas', 0)),
        'gas_price': int(t.get('gasPrice', 0)) if t.get('gasPrice') is not None else None,
        'input': t.get('input'),
        'type': hex_to_int(t.get('type')),
        'max_fee_per_gas': hex_to_int(t.get('maxFeePerGas')),
        'max_priority_fee_per_gas': hex_to_int(t.get('maxPriorityFeePerGas')),
    }

def fetch_block_with_txs(w3: Web3, n: int) -> Dict[str, Any]:
    # full_transactions=True to include tx bodies
    return w3.eth.get_block(n, full_transactions=True)

def main():
    ap = argparse.ArgumentParser(description='Ethereum ETL → Parquet')
    ap.add_argument('--rpc', default=os.getenv('RPC_URL'), help='RPC URL (env RPC_URL if omitted)')
    ap.add_argument('--start', type=int, required=True, help='start block number (inclusive)')
    ap.add_argument('--end', type=int, required=True, help='end block number (inclusive)')
    ap.add_argument('--out', default='parquet', help='output dir (default parquet/)')
    ap.add_argument('--batch', type=int, default=50, help='batch size for progress updates')
    args = ap.parse_args()

    if not args.rpc:
        print('ERROR: RPC URL not provided (use --rpc or set RPC_URL)'); sys.exit(1)

    w3 = Web3(Web3.HTTPProvider(args.rpc))
    if not w3.is_connected():
        print('ERROR: cannot connect to RPC'); sys.exit(1)

    out_blocks = Path(args.out) / 'blocks'
    out_txs = Path(args.out) / 'transactions'
    out_blocks.mkdir(parents=True, exist_ok=True)
    out_txs.mkdir(parents=True, exist_ok=True)

    blocks: List[Dict[str, Any]] = []
    txs: List[Dict[str, Any]] = []

    rng = range(args.start, args.end + 1)
    for i, n in enumerate(tqdm(rng, desc='blocks')):
        try:
            b = fetch_block_with_txs(w3, n)
        except Exception as e:
            print(f'WARN: failed block {n}: {e}'); time.sleep(1); continue
        blocks.append(normalize_block(b))
        for t in b['transactions']:
            txs.append(normalize_tx(t, int(b['number'])))

        # Write in chunks to avoid big memory
        if (i + 1) % args.batch == 0 or n == args.end:
            if blocks:
                dfb = pd.DataFrame(blocks)
                dfb['timestamp'] = pd.to_datetime(dfb['timestamp'], unit='s', utc=True)
                dfb.to_parquet(out_blocks / f'blocks_{blocks[0]["number"]}_{blocks[-1]["number"]}.parquet', index=False)
                blocks.clear()
            if txs:
                dft = pd.DataFrame(txs)
                dft.to_parquet(out_txs / f'txs_{n - len(dft) + 1}_{n}.parquet', index=False)
                txs.clear()

    print('Done. Parquet written to', args.out)

if __name__ == '__main__':
    main()
