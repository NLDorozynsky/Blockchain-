import duckdb, glob, os, pandas as pd

PARQUET_DIR = os.environ.get('PARQUET_DIR', 'parquet')
BLOCKS_GLOB = os.path.join(PARQUET_DIR, 'blocks', '*.parquet')
TXS_GLOB = os.path.join(PARQUET_DIR, 'transactions', '*.parquet')

def main():
    con = duckdb.connect()  # in-memory (or connect('etl.duckdb') to persist)
    con.execute(f"""CREATE VIEW blocks AS SELECT * FROM parquet_scan('{BLOCKS_GLOB}');""")
    con.execute(f"""CREATE VIEW txs AS SELECT * FROM parquet_scan('{TXS_GLOB}');""")

    print('Tables: blocks, txs')

    # Daily tx counts
    q1 = con.execute("""
SELECT date_trunc('day', timestamp) AS day, count(*) AS tx_count
FROM blocks JOIN txs ON txs.block_number = blocks.number
GROUP BY day ORDER BY day;
""").fetchdf()
    print('\nDaily tx counts (head):'); print(q1.head())

    # Top talkers
    q2 = con.execute("""
SELECT "from" AS addr, count(*) AS sent
FROM txs GROUP BY addr ORDER BY sent DESC LIMIT 10;
""").fetchdf()
    print('\nTop senders:'); print(q2)

    # Gas price stats
    q3 = con.execute("""
SELECT quantile_cont(gas_price, 0.5) AS p50, quantile_cont(gas_price, 0.9) AS p90 FROM txs;""").fetchdf()
    print('\nGas price quantiles:'); print(q3)

    # Sample: join and show a block
    q4 = con.execute("""
SELECT b.number, b.hash, b.timestamp, b.tx_count FROM blocks b ORDER BY number DESC LIMIT 5;""").fetchdf()
    print('\nRecent blocks:'); print(q4)

if __name__ == '__main__':
    main()
