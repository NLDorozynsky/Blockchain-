# Ethereum ETL → Parquet + DuckDB — Python/DuckDB

A compact, educational ETL pipeline that pulls Ethereum **blocks & transactions** from an RPC,
writes them to **Parquet**, and queries them with **DuckDB** (locally, no server).

- **`src/etl.py`** — pull a block range (`--start`/`--end`) and save Parquet into `parquet/blocks/` and `parquet/transactions/`
- **`src/duck.py`** — sample DuckDB queries over the Parquet data (daily tx counts, gas stats, top talkers, …)
- **`notebooks/01_quickstart.ipynb`** — notebook walkthrough: load Parquet with DuckDB, plot daily stats

> ⚠️ This is a teaching scaffold, not production-hardened (no reorg handling, retries are basic).

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# edit RPC_URL in .env

# ETL a small range (e.g., last 1000 blocks)
python src/etl.py --start 21000000 --end 21001000

# Run sample DuckDB queries
python src/duck.py

# Open the notebook (optional)
jupyter lab  # notebooks/01_quickstart.ipynb
```

### Output layout
```
parquet/
  blocks/         blocks_21000000_21001000.parquet
  transactions/   txs_21000000_21001000.parquet
```

---

### Tips / TODO
- Add retries/backoff for rate-limited RPCs, and optional concurrency (carefully).
- Partition-by-day or Hive-style partitioning for larger datasets.
- Add receipts & logs tables for event analytics.
- Materialize DuckDB views to a `.duckdb` file if desired (see comments in `src/duck.py`).

© 2025
