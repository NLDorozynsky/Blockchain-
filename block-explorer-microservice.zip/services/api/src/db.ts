import { Pool } from 'pg'; export const pool=new Pool({connectionString:process.env.DATABASE_URL});
export async function getBlocks(limit=20,offset=0){const r=await pool.query('SELECT * FROM blocks ORDER BY number DESC LIMIT $1 OFFSET $2',[limit,offset]); return r.rows;}
export async function getBlock(number:number){const r=await pool.query('SELECT * FROM blocks WHERE number=$1',[number]); return r.rows[0]||null;}
export async function getTxsByBlock(number:number,limit=100,offset=0){const r=await pool.query('SELECT * FROM transactions WHERE block_number=$1 ORDER BY nonce ASC LIMIT $2 OFFSET $3',[number,limit,offset]); return r.rows;}
export async function getTx(hash:string){const r=await pool.query('SELECT * FROM transactions WHERE hash=$1',[hash]); return r.rows[0]||null;}
export async function getTxsByAddress(addr:string,limit=50,offset=0){const r=await pool.query('SELECT * FROM transactions WHERE "from"=$1 OR "to"=$1 ORDER BY block_number DESC LIMIT $2 OFFSET $3',[addr,limit,offset]); return r.rows;}
