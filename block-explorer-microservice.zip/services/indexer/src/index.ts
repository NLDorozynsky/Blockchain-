import 'dotenv/config'; import { ethers } from 'ethers'; import { pool, upsertBlock, insertTransactions, latestStored } from './db.js';
const RPC_URL=process.env.RPC_URL!; const START_BLOCK=process.env.START_BLOCK?Number(process.env.START_BLOCK):undefined; const POLL_INTERVAL_MS=process.env.POLL_INTERVAL_MS?Number(process.env.POLL_INTERVAL_MS):3000;
const provider=new ethers.JsonRpcProvider(RPC_URL);
async function head(){ return Number(await provider.getBlockNumber()); }
async function getStart(){ const stored=await latestStored(); if(stored!==null) return stored+1; const h=await head(); return START_BLOCK ?? Math.max(0,h-100); }
async function indexOnce(fr:number,to:number){ for(let n=fr;n<=to;n++){ const bw=await provider.getBlockWithTransactions(n); if(!bw) continue; await upsertBlock(bw); await insertTransactions(n,bw.transactions); console.log(`Indexed block ${n} (${bw.transactions.length} txs)`);}}
async function run(){ console.log('Indexer starting...'); await pool.query('SELECT 1'); let next=await getStart(); console.log('Starting from block',next); while(true){ const h=await head(); if(h>=next){ await indexOnce(next,h); next=h+1; } await new Promise(r=>setTimeout(r,POLL_INTERVAL_MS)); } }
run().catch(e=>{console.error(e);process.exit(1)});
