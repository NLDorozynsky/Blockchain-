-- Basic explorer schema (blocks, transactions)
CREATE TABLE IF NOT EXISTS blocks (
  number BIGINT PRIMARY KEY,
  hash TEXT NOT NULL,
  parent_hash TEXT NOT NULL,
  timestamp TIMESTAMPTZ NOT NULL,
  miner TEXT,
  gas_used NUMERIC,
  gas_limit NUMERIC,
  tx_count INT NOT NULL
);

CREATE TABLE IF NOT EXISTS transactions (
  hash TEXT PRIMARY KEY,
  block_number BIGINT REFERENCES blocks(number) ON DELETE CASCADE,
  "from" TEXT NOT NULL,
  "to" TEXT,
  value NUMERIC,
  nonce INT,
  gas_price NUMERIC,
  gas_limit NUMERIC,
  input TEXT
);

CREATE INDEX IF NOT EXISTS idx_tx_block ON transactions(block_number);
CREATE INDEX IF NOT EXISTS idx_tx_from ON transactions("from");
CREATE INDEX IF NOT EXISTS idx_tx_to ON transactions("to");
