# Block Explorer Microservice (indexer + API + UI) — Node/Express/Postgres/Next.js

A lightweight explorer stack:

- **Indexer (Node + ethers + Postgres)**: streams blocks & transactions from an EVM RPC to Postgres.
- **API (Express + Postgres)**: REST endpoints for blocks, txs, addresses.
- **UI (Next.js)**: simple web that lists blocks and shows block/tx/address pages.
- **Postgres** schema + docker-compose to spin up DB quickly.

> Educational scaffold — not production ready.

## Quick start (local dev)

### 1) Start Postgres
```bash
docker compose up -d db
# or: docker-compose up -d db
```

### 2) Create schema
```bash
psql "postgresql://postgres:postgres@localhost:5432/explorer" -f db/schema.sql
```

### 3) Run the API
```bash
cd services/api
cp .env.example .env
# set DATABASE_URL (default in example) and CORS as needed
npm i
npm run dev
```

### 4) Run the indexer
```bash
cd ../indexer
cp .env.example .env
# set RPC_URL, START_BLOCK, DATABASE_URL
npm i
npm run dev
```

### 5) Run the UI
```bash
cd ../../web
cp .env.example .env.local   # set NEXT_PUBLIC_API_BASE (defaults ok)
npm i
npm run dev
# open http://localhost:3000
```

## Services

- **Indexer** env:
  - `RPC_URL` (e.g., `https://eth.llamarpc.com` or local Anvil)
  - `DATABASE_URL` (e.g., `postgres://postgres:postgres@localhost:5432/explorer`)
  - `START_BLOCK` (optional, default: chain head - 100)
  - `POLL_INTERVAL_MS` (default 3000)

- **API** env:
  - `DATABASE_URL`
  - `PORT` (default 4000)
  - `CORS_ORIGIN` (default `http://localhost:3000`)

- **Web** env:
  - `NEXT_PUBLIC_API_BASE` (default `http://localhost:4000`)

## Docker
`docker-compose.yml` includes Postgres only to keep it simple.
